// FUNCION LINEAL.
#include <cstdlib>
#include <iostream>
void mensaje()
{
         printf("\n HOLA\n");

}// fin de la funcion.
using namespace std;

int main(int argc, char *argv[])
{
    for(int a=1;a<=5;a++)
    mensaje();
    system("PAUSE");
    return EXIT_SUCCESS;
}
