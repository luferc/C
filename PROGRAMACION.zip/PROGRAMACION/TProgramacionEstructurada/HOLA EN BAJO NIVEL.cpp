#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    /* Programa en bajo nivel*/
    /* Primer programa..(HOLA)*/
    /* Autor: Cervantes Martinez Luis Fernando */
    /* codigo: 304776313 */
    
    system("CLS");
    cout<< "********************\n*                  *\n*       HOLA       *\n*                  *\n*                  *\n********************\n";
    cout<< "********************\n*                  *\n*       HOLA       *\n*                  *\n*                  *\n********************\n";
    cout<< "********************\n*                  *\n*       HOLA       *\n*                  *\n*                  *\n********************\n";
    cout<< "********************\n*                  *\n*       HOLA       *\n*                  *\n*                  *\n********************\n";
    system ("PAUSE");
    return EXIT_SUCCESS;
}
