/* NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO. 
   CODIGO: 304776313
   MATERIA: TALLER PROGRAMACION ESTRUCTURADA.
   FECHA: JUEVES 04, DE JUNIO, DEL 2008.
   EXAMEN: EJERCICIO  */
#include <cstdlib>
#include <iostream>
using namespace std;
// FUNCIONES.

char nombre()//........FUNCION SIMPLE.
{
     char nom[30];
     printf("\n\n");
     printf("\n\n\t NOMBRE: ");
     scanf("%s",&nom);
     printf("\n\n\t SU NOMBRE ES: %s \n\n",nom);

 }
 
 int edad(int ed)//....FUNCION CON PARAMETROS.
 {
     printf("\n\n");
     printf("\n\n\t EDAD: %i \n\n",ed);
 }
 
 int validar(int eda)//.FUNCION REGRESA PARAMETROS.
 {
         printf("\n\n\t EDAD: %i",eda);
         return eda;
 }
 
int main(int argc, char *argv[])
{
    // INICIO MAIN.
    // DECLARACION VARIABLES.
    int a,e;
    a=0;
    // DATOS ENTRADA.
    while(a!=4)
    {
                printf("\t ................................\n");
                printf("\t ............ MENU ..............\n");
                printf("\t . (1)....NOMBRE                .\n");
                printf("\t . (2)....EDAD                  .\n");
                printf("\t . (3)....VALIDAR               .\n");
                printf("\t . (4)....SALIR                 .\n");
                printf("\t ................................\n");
                printf("\n\n\n");
                printf("\t SELECCIONE: ");
                scanf("%i",&a);
                system("cls");
                switch(a)
                {
                          case 1: // nombre.
                          //printf("\n\n\t NOMBRE: ");
                          nombre();
                          break;
                          
                          case 2: // edad.
                          printf("\n\n\t EDAD: ");
                          scanf("%i",&e);
                          edad(e);
                          break;
                          
                          case 3:// validar.
                          int sal;
                          printf("\n\n\t EDAD: ");
                          scanf("%i",&e);
                          sal = validar(e);
                               if(sal>=17)
                                           {
                                             printf("\n\n\t VOTAS \n");
                                             }
                               else
                                             {    
                                               printf("\n\n\t NO VOTAS \n");
                                              }
                          break;
                          
                          case 4:// salir.
                          printf("\n\n\n");
                          printf("\n\n\t FIN \n\n");
                          break;
                          
                          default:
                                  printf("\n\n\n");
                                  printf("\n\n\t   ERROR   \n");
                                  printf("\n\n\t 1  -    4 \n");
                                  printf("\n\n\n");
                                  }//FIN DE SWITCH.
    system("PAUSE");
    system("cls");
}// fin de while
    return EXIT_SUCCESS;
}// FIN DE MAIN.
