/* NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO. 
   CODIGO: 304776313
   MATERIA: TALLER PROGRAMACION ESTRUCTURADA.
   FECHA: JUEVES 28 DE MAYO DEL 2008.
   EXAMEN: EJERCICIO #1 2 PTS. */
#include <cstdlib>
#include <iostream>

using namespace std;
// FUNCION LINEAL O SIMPLE:
           char nombre(char a){          
                printf("\n\n\t NOMBRE:  ",a);
                scanf("%c",&a);
                return 0;}
           int edad(int b){
                printf("\n\n\t EDAD: ",b);
                scanf("%i",&b);
                return 0;}
int main(int argc, char *argv[])
{
    // CUERPO MAIN.
    // DECLARACIONDE VARIABLES.
char c;
int d;
    //DATOS DE ENTRADA:
            printf("\n\n\t....REGISTRO....");
            printf("\n\n\t 1....NOMBRE:   ");
            nombre(c); // LLAMAR FUNCION.
            
            printf("\n\n\t 2....EDAD:     ");
            edad(d);// LLAMAR FUNCION.
            
    system("PAUSE");
    return EXIT_SUCCESS;
}
