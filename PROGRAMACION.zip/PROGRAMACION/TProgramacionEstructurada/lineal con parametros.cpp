#include <cstdlib>
#include <iostream>

using namespace std;
int mensaje(int x)
{
     for(int a=1;a<=x;a++)
     printf("\n HOLA\n",a);
     printf("\n FIN DE LA FUNCION\n");
     return 0;
     }
int main(int argc, char *argv[])
{
    int cuantas;
    
     printf("\n cuantas veces quieres imprimir el mensaje? ");
    scanf("%i",&cuantas);
    
    mensaje(cuantas);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
