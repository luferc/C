#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int edad [5];
    // Captura de Datos.
    printf ("** CAPTURA DE DATOS **\n\n");
    printf ("\n TECLEA LA EDAD [1]:");
    scanf ("%i",&edad[0]);
    printf ("\n TECLEA LA EDAD [2]:");
     scanf ("%i",&edad[1]);
    printf ("\n TECLEA LA EDAD [3]:");
     scanf ("%i",&edad[2]);
    printf ("\n TECLEA LA EDAD [4]:");
     scanf ("%i",&edad[3]);
    printf ("\n TECLEA LA EDAD [5]:");
     scanf ("%i",&edad[4]);
     // Slida de Datos.
     printf ("\n\n ** SALIDA DE DATOS **\n");
     printf ("\n EDAD CAPTURADA [1] = %i",edad[0]);
     printf ("\n EDAD CAPTURADA [2] = %i",edad[1]);
     printf ("\n EDAD CAPTURADA [3] = %i",edad[2]);
     printf ("\n EDAD CAPTURADA [4] = %i",edad[3]);
     printf ("\n EDAD CAPTURADA [5] = %i",edad[4]);
     printf ("\n\n FIN DEL PROGRAMA\n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
