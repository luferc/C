#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int altura,radio,volumen;
    float pi=3.14159;
    printf ( "introduzca la altura del cilindro:\n");
    scanf ( "%f",&altura );
    printf ( "introduzca el radio del cilindro:\n" );
    scanf ( "%f",&radio );
    volumen=altura*pi*radio*radio;
    printf ( "el volumen de su cilindro es: %d\n",volumen );
    system("PAUSE");
    return EXIT_SUCCESS;
}
