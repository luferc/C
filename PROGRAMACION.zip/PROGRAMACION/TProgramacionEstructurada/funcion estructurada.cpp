// FUNCION ESTRUCTURADA.
#include <cstdlib>
#include <iostream>

using namespace std;
void mensaje();

int main(int argc, char *argv[])
{
    for(int a=1;a<=5;a++)
    mensaje();
    system("PAUSE");
    return EXIT_SUCCESS;
}
void mensaje()
{
         printf("\n HOLA \n");
         }
