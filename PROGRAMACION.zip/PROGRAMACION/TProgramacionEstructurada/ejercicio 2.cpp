/* NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO. 
   CODIGO: 304776313
   MATERIA: TALLER PROGRAMACION ESTRUCTURADA.
   FECHA: JUEVES 28 DE MAYO DEL 2008.
   EXAMEN: EJERCICIO #2 4 PTS. */
#include <cstdlib>
#include <iostream>

using namespace std;
// FUNCION
int edad(int b)
{
    if (b>=17)
    printf("\n\n\t PUEDES VOTAR..!!\n\n");
    else 
    printf("\n\n\t NO PUEDES VOTAR...!\n");
    return 0;
}
int main(int argc, char *argv[])
{
        // CUERPO MAIN.
        // DECLARACIONDE VARIABLES.
        int a;
        //DATOS DE ENTRADA:
               printf("\n\n\t....VOTACIONES....\n\n");
               printf("\n\n\t 1.....EDAD: ");
               scanf("%i",&a);
               edad(a); 
    system("PAUSE");
    return EXIT_SUCCESS;
}
