#include <cstdlib>
#include <iostream>

using namespace std;

     /* Programa en Alto nivel */
    /* Programa para calcular el Area de un Circulo */
   /* Autor: Cervantes Martinez Luis Fernando */
  /* codigo: 304776313 */
int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    float p=3.1416;
    float area,radio;
    /* Datos de Entrada */
    printf ("...............PROGRAMA CALCULADOR DE AREA DE UN CIRCULO...............\n");
    printf ("\n\n FORMULA = \t AREA = PI X RADIO X RADIO\n");
    printf ("\n\n\t INTRODUZCA EL RADIO DEL CIRCULO: ");
    scanf ("%f",&radio);
    /* Operaciones */
    area = p=3.1416 *radio *radio;
    /* Datos de Salida */
    printf ("\n\n\t AREA = %f\n",area);
    printf ("\n\n..........By: FERNANDO CERVANTES..........\n\n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
