#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int x=0;
    do
    {
        printf ("\n HOLA");
        x++;
        }
        while (x<=5);
    system("PAUSE");
    return EXIT_SUCCESS;
}
