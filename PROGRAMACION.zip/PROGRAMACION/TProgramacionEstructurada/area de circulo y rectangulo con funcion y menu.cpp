#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;
/* RECTANGULO */
float calcular(float a,float b)// Funcion.
{
    float area;
    area = b * a; // FORMULA.
    printf("\n\t AREA = %i\n\n",area);
    return 0;
    }//fin de la funcion.
    
 /* CIRCULO */
 
float calcular(float radio);   

int main(int argc, char *argv[])
{
        /* Declaracion de Variables */
        int op=1;
        float r;
        float ba,al;
        
        while (op!=3)
        {
              printf("\n\n\t          MENU    \n");  
              printf("\n\t   (1)...RECTANGULO \n");
              printf("\n\t   (2)...CIRCULO    \n");
              printf("\n\t   (3)...SALIR      \n");
              printf("\n\n\t SELECCIONE UNA OPCION: ");
              scanf("%i",&op);
              system("cls");
              switch (op)
              {
              case 1:
                    /* Datos de Entrada */
                    printf("\n\t INTRODUZCA LO SIGUIENTE: \n");
                    printf("\n\t BASE = ");
                    scanf("%f",&ba);
                    printf("\n\t ALTURA = ");
                    scanf("%f",&al);
                    calcular(ba,al);//llamar funcion.
                    break;
                    case 2:
                         /* Datos de Entrada */
                         printf ("\n\n\n...............PROGRAMA CALCULADOR DE AREA DE UN CIRCULO...............\n");
                         printf ("\n\n FORMULA = \t AREA = PI X RADIO X RADIO\n");
                         printf ("\n\n\t INTRODUZCA EL RADIO DEL CIRCULO: ");
                         scanf ("%f",&r);
                         calcular(r);//Llamar Funcion.
                         break;
                         case 3:
                              printf("\n\n\t FIN \n\n");
                              break;
                              default:
                                      printf("\n\n\t OPCION INVALIDA\n\n");
                                      }//fIN DE SWITCH.
    system("PAUSE");
    system("cls");
}//FIN DE WHILE.
    return EXIT_SUCCESS;
}//FIN DE MAIN.

float calcular(float r)//Funcion.
{
      float pi=3.1416;
      float area;
          /* Operaciones */
          area = pi * r *r;
          /* Datos de Salida */
          printf ("\n\n\t AREA = %f\n",area);
          }

