#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int m;
    for (m=1;m<=20;m++)
    {
        printf("\n hola\n");
        }
    system("PAUSE");
    return EXIT_SUCCESS;
}
