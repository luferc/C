#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int a,i;
    printf ("\t TABLA DEL 2\n");
    for (i=1;i<=10;i++)
    {
        a=2*i;
        printf("\n 2 x %i = %i \n",i,a);
        }
    system("PAUSE");
    return EXIT_SUCCESS;
}
