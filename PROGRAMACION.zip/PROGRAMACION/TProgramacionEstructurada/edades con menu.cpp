#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    int edad[6]; // Arreglo.
    int i,x;
    int opcion=1; // Menu.
    /* Datos de Entrada */
  
       while ( opcion !=5 ){
              printf ("\t\t ���������������\n");
              printf ("\t\t �             �\n");
              printf ("\t\t �    EDADES   �\n");
              printf ("\t\t �             �\n");
              printf ("\t\t ���������������\n");
              printf ("........................MENU...........................\n");
              printf ("\t     (1)....INTRODUCIR DATOS\n");
              printf ("\t     (2)....CONSULTAR DATOS\n");
              printf ("\t     (3)....MODIFICAR DATOS\n");
              printf ("\t     (4)....BORRAR DATOS\n");
              printf ("\t     (5)....SALIR DEL PROGRAMA\n");
              printf ("SELECCIONE UNA OPCION:");
              scanf ("%d",&opcion);
               system("cls");
                   switch (opcion)
              {
                     case 1:
                            printf ("** CAPTURA DE DATOS **\n\n");
                            for (i=1;i<6;i++)//ciclo
                            {
                                printf ("\n TECLEA LA EDAD [%i]:",i);
                                scanf ("%i",&x);
                                edad[i]=x;
                                }
                                 break;
                                 case 2:
                                        printf("\n** CONSULTA DE DATOS **\n\n");
                                        for (i=1;i<6;i++)
                                        {
                                            printf("\n EDAD CAPTURADA [%i]: %i\n",i,edad[i]);
                                            }
                                            break;
                                            case 3:
                                                 printf ("** MODIFIQUE LOS DATOS **\n\n");
                                                 for (i=1;i<6;i++)//ciclo
                                                 {
                                                     printf ("\n SELECCIONE LA EDAD [%i]:%i\n",i,edad[i]);
                                                     }
                                                     printf ("\n �CUAL EDAD DESEA MODIFICAR? ",i);
                                                     scanf("%i",&i);
                                                     printf ("\n NUEVA EDAD     [%i]:",i,edad[x]);
                                                     scanf ("%i",&x);
                                                     edad[i]=x;
                                                     break;
                                                     case 4:
                                                          printf ("\n** BORRAR DATOS **\n\n");
                                                                     for (i=1;i<6;i++)//ciclo
                                                                     {
                                                                         printf("\n EDAD CAPTURADA [%i]: %i\n",i,edad[i]);
                                                                         }
                                                                         printf ("\n CUAL EDAD DESEA BORRAR?",i);
                                                                         scanf ("%i",&i);
                                                                         edad[i]=0;
                                                                      printf("\n EDAD CAPTURADA [%i]: %i\n",i,edad[i]);
                                                                         
                                                                      break;
                                                          case 5:
                                                               printf ("\n.....GRACIAS POR USAR ESTE PROGRAMA\n.....QUE TENGA BUEN DIA..!\n");
                                                               printf ("\n...............By: FERNANDO CERVANTES..............\n\n");
                                                               break;
                                                               default:
                                                                       printf("\n....OPCION INVALIDA....\n");
                                                                       
                                                                       } // switch  - case
                                                
                                                                       
    system("PAUSE");
    system("cls");
    } // while()
    return EXIT_SUCCESS;
}

