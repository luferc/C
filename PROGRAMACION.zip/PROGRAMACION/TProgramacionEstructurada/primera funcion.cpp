#include <cstdlib>
#include <iostream>
#include <string.h>

using namespace std;
/* Funcion */
 bool nombre( char f[10])
{
     printf("\t\n\n SU NOMBRE ES: %s\n",f);
       return 0;
     }
int edad(int y)
{
   printf("\t\n\n SU EDAD ES: %i\n",y); 
    return 0;
    }
int main(int argc, char *argv[])
{
    char a[10];
    int x;
    printf("\t\n\n INGRESE SUS DATOS:");
    
    printf("\t\n\n NOMBRE: ");
    gets(a);
    nombre(a);
    
    printf("\t\n\n EDAD: ");
    scanf("%i",&x);
    edad(x);
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
