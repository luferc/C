#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    /* Declaracion de variables */
    int base=5;
    int altura=10;
    int area=0;
    /* formula */
    area=base*altura;
    /* Datos de salida */
    printf ("*****PROGRAMA PARA CALCULAR EL AREA DE UN RECTANGULO******\n");
    printf ("\n LA ALTURA = %i",altura);
    printf ("\n EL BASE = %i",base);
    printf ("\n EL AREA = %i",area);
    printf ("\n*****FIN DEL PROGRAMA*****\n");
    
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
