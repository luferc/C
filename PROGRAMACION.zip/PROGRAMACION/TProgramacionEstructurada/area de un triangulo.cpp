#include <cstdlib>
#include <iostream>

using namespace std;

      /* Programa en Alto nivel */
     /* Programa para sacar el Area de un Triangulo */
    /* Autor: Cervantes Martinez Luis Fernando */
   /* codigo: 304776313 */

int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    float area, base, altura;
    /* Datos de Entrada */
    printf ("..........PROGRAMA CALCULADOR DE AREA PARA UN TRAINGULO..........\n\n");
    printf ("\n FORMULA =\t BASE  X ALTURA\n");
    printf ("\t\t................\n");
    printf ("\t\t\t2\n");
    printf ("       *\n      **\n     ****\n   *******\n  *********\n ***********\n*************\n");
    printf ("\n\t INTRODUZCA LA BASE DEL TRIANGULO: ");
    scanf ("\%f",&base);
    printf ("\n\t INTRODUZCA LA ALTURA DEL TRIANGULO: ");
    scanf ("\%f",&altura); 
    /* Operaciones */
    area = (base * altura)/2;
    /* Datos de Salida */
    printf ("\n\t AREA = %f\n",area);
    printf ("\n...............By: FERNANDO CERVANTES..............\n\n");
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
