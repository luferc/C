#include <cstdlib>
#include <iostream>
#define  MAX   5

using namespace std;
/* FUNCIONES */
int edad [5];// INGRESAR.
int i;
int altas()
{
    printf(" .... ENTRADA DE DATOS ...\n");
    for (int a=0;a<=4;a++)
    {
    printf("\n Escribe la edad :");
    scanf("%i",&edad[a]);
    edad[i]=a;
    }
    printf("\n\n FIN DE CAPTURA \n\n");
}// FIN DE INGRESO.
int consultas()// CONSULTAS.
{
    printf(" .... SALIDA DE DATOS ...\n");
    for (int b=0;b<=4;b++)
    {
    printf("\n Edad capturada = %i",edad[b]);
    }
    printf("\n\n FIN DE LA CONSULTA \n\n");
}// FIN DE CONSULTAS

char res;
int bajas ()// BAJAS.
{
    printf(" .... BORRADO DE DATOS ...\n");
    for (int c=0;c<=4;c++)
    {
    printf("\n Edad capturada : %i",edad[c]);
    printf("\n\n BORRAR ESTE DATO? (s - n):");
    scanf("%s",&res);
    if (res=='s') edad[c]= 0;
    }
    printf("\n\n NO HAY MAS DATOS PARA ELIMINAR \n\n");
}// FIN DE BAJAS.
int main(int argc, char *argv[])// CUERPO PRINCIPAL MAIN.
{
    /* DECLARACION DE VARIABLES */
    int op,x;
    /* DATOS DE ENTRADA */
    while (op!=4)
        {
                 printf("\n\n\t         EDADES   \n"); 
                 printf("\n\n\t  (1)....ENTRADA  \n");
                 printf("\n\n\t  (2)....CONSULTA \n");
                 printf("\n\n\t  (3)....BORRAR   \n");
                 printf("\n\n\t  (4)....SALIR    \n");
                 printf("\n\n\t  SLECCIONE:        ");
                 scanf("%i",&op);
                 system("cls");
                 switch (op)
                 {
                        case 1: altas();
                             break;
                             
                             case 2: consultas();
                                break;
                                
                             case 3: bajas();
                                break;
                                                                        
                } // switch  - case
        
                  system("PAUSE");
                  system("cls");
       }//FIN DE WHILE.
    return EXIT_SUCCESS;
}//fin de main.
