#include <cstdlib>
#include <iostream>
#include <math.h>

using namespace std;
       /*---------------------------------------------------*/
      /* Programa en Alto nivel */
     /* Programa #5: para calcular la Ecuacion cudratica */
    /*-----------------------------------------------------*/
   /* Autor: Cervantes Martinez Luis Fernando */
  /* codigo: 304776313 */
 /* fecha: 26 de febrero del 2009 */
/*----------------------------------------------------------*/

int main(int argc, char *argv[])
{
    /* Declaracion de variables */
    float a,b,c;
    float raiz1,raiz2,x1,x2;
    /* Datos de Entrada */
    printf ("\n..........PROGRAMA CALCULADOR DE LA ECUACION CUDRATICA........................\n");
    printf ("\n\n\t INTRODUZCA EL VALOR DE ( a ): ");
    scanf ("%f",&a);
    printf ("\n\n\t INTRODUZCA EL VALOR DE ( b ): ");
    scanf ("%f",&b);
    printf ("\n\n\t INTRODUZCA EL VALOR DE ( c ): ");
    scanf ("%f",&c);
    
          raiz1= (b*b)-(4*a*c);
          
    if (raiz1 > 0){
           
              raiz2 = sqrt (raiz1);
              
                   x1 = (-b+raiz2)/2*a;
                   x2 = (-b-raiz2)/2*a;
                   printf ("\n\t LA RAIZ 1 = %f\n",x1);
                   printf ("\n\t LA RAIZ 2 = %f\n",x2);
              }
              else {
                   printf ("\n....LA RAIZ ES NEGATIVA.....ERROR.......\n");
                   }
    
    
        system("PAUSE");
    return EXIT_SUCCESS;
}
/* Una ecuaci�n cuadr�tica, o de segundo grado, con una inc�gnita x, 
es una ecuaci�n de la forma indicada, donde a, b, y c son n�meros reales dados, 
con a distinto de cero. Se puede resolver empleando la f�rmula cuadr�tica.
 Si b2>4ac hay dos soluciones reales distintas; si b2=4ac hay una sola soluci�n real; si b2<4ac no hay soluciones reales,
  pero s� dos soluciones complejas conjugadas.*/
