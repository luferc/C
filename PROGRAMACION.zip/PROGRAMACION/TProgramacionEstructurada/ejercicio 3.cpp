/* NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO. 
   CODIGO: 304776313
   MATERIA: TALLER PROGRAMACION ESTRUCTURADA.
   FECHA: JUEVES 28 DE MAYO DEL 2008.
   EXAMEN: EJERCICIO #3 4 PTS. */
#include <cstdlib>
#include <iostream>

using namespace std;
// FUNCION
int pd(int b)
{
    printf("\n\n\t PESOS A DOLARES");
    scanf("%i",&b);
   int c = b/10;
   printf("\n\n\t CONVERCION = %i",c);
    return 0
}
int dope(int e,f)
{
    printf("\n\n\t DOLARES A PESOS");
    scanf("%i",&e);
    int f = e*10;
    printf("\n\n\t CONVERCION = %i",f);
    return 0;
}
int main(int argc, char *argv[])
{
    // CUERPO MAIN.
    // DECLARACIONDE VARIABLES.
    int op,a,d;
    //DATOS DE ENTRADA:
            while (!=3){
                              printf("\n\n\t 1....PESOS A DOLARES\n");
                              printf("\n\n\t 2....DOLARES A PESOS \n");
                              printf("\n\n\t 3....NO CALCULOS    \n");
                              printf("\n\n\t ELIJE UNA OPCION: ");
                              scanf("%i",&op);
                              system ("cls");
                              switch (op)
                              {
                                     case 1:
                                          printf("\n\n\t PESOS A DOLARES");
                                           pd(a);
                                     break;
                                     case 2: dope(d);
                                     break;
                                     case 3:
                                          printf("\n\n\t GRACIAS POR USAR ESTE CONVERTIDOR\n");
                                     break;
                                     default: 
                                              printf("\n\n\t ERROR OPCION INCORRECTA");
                                              }//FIN DE SWITCH.

    system("PAUSE");
    system("cls");
}// fin de while.
    return EXIT_SUCCESS;
}
