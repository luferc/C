#include <cstdlib>
#include <iostream>

using namespace std;
     /* Programa en Alto nivel */
    /* Programa para calcular el Area de un Circulo y un Triangulo con Menu */
   /* Autor: Cervantes Martinez Luis Fernando */
  /* codigo: 304776313 */
int main(int argc, char *argv[])
{
     /* Declaracion de Variables */
    float area, base, altura; /* Triangulo */
    float p=3.1416; /* Circulo */
    float area2,radio; /* Circulo */
    int opcion=1; /* Menu */
    /* Datos de Entrada */
     printf ("********************************************************************************\n*********************PROGRAMA CALCULADOR DE AREAS***********************************************************************************************************\n");
        while ( opcion !=3 ){
              system("cls");
              printf ("........................MENU..........................\n");
              printf ("\t     (1)....AREA DE UN TRIANGULO\n");
              printf ("\t     (2)....AREA DE UN CIRCULO\n");
              printf ("\t     (3)....SALIR DEL PROGRAMA\n");
              printf ("SELECCIONE UNA OPCION:");
              scanf ("%d",&opcion);
               system("cls");
              switch (opcion)
              {
                     case 1:
                           
                              printf ("..........PROGRAMA CALCULADOR DE AREA PARA UN TRAINGULO..........\n\n");
    printf ("\n FORMULA =\t BASE  X ALTURA\n");
    printf ("\t\t................\n");
    printf ("\t\t\t2\n");
    printf ("       *\n      **\n     ****\n   *******\n  *********\n ***********\n*************\n");
    printf ("\n\t INTRODUZCA LA BASE DEL TRIANGULO: ");
    scanf ("\%f",&base);
    printf ("\n\t INTRODUZCA LA ALTURA DEL TRIANGULO: ");
    scanf ("\%f",&altura); 
    /* Operaciones */
    area = (base * altura)/2;
    /* Datos de Salida */
    printf ("\n\t AREA = %f\n",area);
    break;
                    case 2: 
                          printf ("...............PROGRAMA CALCULADOR DE AREA DE UN CIRCULO...............\n");
    printf ("\n\n FORMULA = \t AREA = PI X RADIO X RADIO\n");
    printf ("\n\n\t INTRODUZCA EL RADIO DEL CIRCULO: ");
    scanf ("%f",&radio);
    /* Operaciones */
    area2 = p=3.1416 *radio *radio;
    /* Datos de Salida */
    printf ("\n\n\t AREA = %f\n",area2);
    break;
                   case 3:
                          
                         printf ("\n.....GRACIAS POR USAR ESTE PROGRAMA\n.....QUE TENGA BUEN DIA..!\n");
                          break;                       
                     default:
                          printf("\n....OPCION INVALIDA....\n");
                          } // switch  - case
    printf ("\n...............By: FERNANDO CERVANTES..............\n\n");
    system("PAUSE"); 
                           } // while()
    return EXIT_SUCCESS;
}
