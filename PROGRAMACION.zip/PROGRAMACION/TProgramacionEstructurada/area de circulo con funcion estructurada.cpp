/* AREA DE UN CIRCULO CON */
/* FUNCION ESTRUCTURADA */
#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;
/* Declaracion de Funcion */
float calcular(float radio);

int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    float r;
    
    /* Datos de Entrada */
     printf ("\n\n\n...............PROGRAMA CALCULADOR DE AREA DE UN CIRCULO...............\n");
    printf ("\n\n FORMULA = \t AREA = PI X RADIO X RADIO\n");
    printf ("\n\n\t INTRODUZCA EL RADIO DEL CIRCULO: ");
    scanf ("%f",&r);
    
    calcular(r);//Llamar Funcion.
    
    system("PAUSE");
    return EXIT_SUCCESS;
}//Fin de main.
float calcular(float r)//Funcion.
{
      float pi=3.1416;
      float area;
          /* Operaciones */
          area = pi * r *r;
          /* Datos de Salida */
          printf ("\n\n\t AREA = %f\n",area);
          }
