#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    /*Declaracion de Variables*/
  int cat1,cat2;
  float hipo;
  /*Datos de Entrada*/
  printf ("introduzca el primer cateto\n");
  scanf ("%d",&catx);
  printf ("introduzaca el segundo cateto\n");
  scanf ("%d",&cat2);
  hipo=(cat1*cat1)+(cat2*cat2);
  /*Datos de Salida*/
  printf ("la hipotenusa del triengulo es: %f",hipo);
  system("PAUSE");	
  return 0;
}
