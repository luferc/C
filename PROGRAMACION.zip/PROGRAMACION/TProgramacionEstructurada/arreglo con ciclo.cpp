#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    // Declaracion de Variables.
    int i,edad[6];//Arreglo.
    int n=1,x,sum;
    //Datos de Entrada.
    printf ("** CAPTURA DE DATOS **\n\n");
    
    for (i=1;i<6;i++)//ciclo
    {
        printf ("\n TECLEA LA EDAD [%i]:",i);
        scanf ("%i",&x);
        edad[i]=x;
        }
        //Datos de Salida.
        printf("\n** SALIDA DE DATOS **\n\n");
        for (i=1;i<6;i++)
    {
        printf("\n EDAD CAPTURADA [%i]: %i\n",i,edad[i]);
        }
        sum=x+i+x;
        edad[i]=sum;
        printf("\n TOTAL DE EDADES = %i",edad[i],sum);
        printf("\n\n FIN DEL PROGRAMA\n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
