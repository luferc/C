#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n,a,i;
    system("cls");
    printf ("\t LAS TABLAS \n");
    printf ("\n\t COLOQUE UN NUMERO PARA MOSTRAR LA TABLA\n");
    scanf ("%i",&n);
    for (i=1;i<=10;i++)
    {
       a=n*i;
       printf ("\t %i x %i = %i \n",n,i,a);
       system("PAUSE");
       } 
       
       n++;   
       for (i=1;i<=10;i++)
    {
       a=n*i;
       printf ("\t %i x %i = %i \n",n,i,a);
       system("PAUSE");
       } 
       n++;
       for (i=1;i<=10;i++)
    {
       a=n*i;
       printf ("\t %i x %i = %i \n",n,i,a);
       system("PAUSE");
       } 
       n++;
       for (i=1;i<=10;i++)
    {
       a=n*i;
       printf ("\t %i x %i = %i \n",n,i,a);
       system("PAUSE");
       }          
    system("PAUSE");
    return EXIT_SUCCESS;
}
