#include <cstdlib>
#include <iostream>
#include <stdio.h>

using namespace std;

int calcular(int a,int b)// Funcion.
{
    int area;
    area = b * a; // FORMULA.
    printf("\n\t AREA = %i\n\n",area);
    return 0;
    }//fin de la funcion.
    
int main(int argc, char *argv[])// main.
{
    /* Declaracion de Variables */
    int ba,al;
    
    /* Datos de Entrada */
     printf("\n\t INTRODUZCA LO SIGUIENTE: \n");
    
    printf("\n\t BASE = ");
    scanf("%i",&ba);
    
    printf("\n\t ALTURA = ");
    scanf("%i",&al);
    
    calcular(ba,al);//llamar funcion.
    
    system("PAUSE");
    return EXIT_SUCCESS;
}// Fin de main.

