#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int n[ 10 ];
  int i,p; /*contador*/
  
  /*entrada*/
  printf ("introduze 10 numeros:\n");
  scanf ("%d%d%d%d%d%d%d%d%d%d",&1,&2,&3,&4,&5,&6,&7,&8,&9,&10);
  
  for ( p = 0; p < 10; p++ ) {
      n[ p ] = 0;
      }
      printf ( "%s%13\n","pares","impares" );
      for ( i = 0; i < 10; i++ ) {
          printf ( "%7d%13d\n",i,n[ i ]);
          } 
  system("PAUSE");	
  return 0;
}
