#include <stdio.h>
#include <stdlib.h>

int main()
{
  int suma = 0;
  int numero;
  for ( numero = 2; numero <= 100; numero +=2  ) {
      suma += numero;
      }
      printf ( "la suma es %d\n", suma );
  system("PAUSE");	
  return 0;
}
