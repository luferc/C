#include <stdio.h>
#include <stdlib.h>
float pulgacm (float a);
float cmapulg (float b);
int main(int argc, char *argv[])
{
    /*Declaracion de Variables*/
    float pulg;
    float cm;
    int opcion=1;
    /*Datos de Entrada*/
    printf ("********************************************************************************\n*********************PROGRAMA CONVERTIDOR DE UNIDADES***********************************************************************************************************\n");
        while ( opcion !=3 ){
              printf ("........................MENU..........................\n");
              printf ("\t     (1)....PULGADAS A CENTIMETROS\n");
              printf ("\t     (2)....CENTIMETROS A PULGADAS\n");
              printf ("\t     (3)....SALIR DEL PROGRAMA\n");
              printf ("SELECCIONE UNA OPCION:");
              scanf ("%d",&opcion);
              switch (opcion)
              {
                     /*Datos de Salida*/
                     case 1:
                          printf ("INTRODUZCA LA CANTIDAD PARA CONVERTIR EN CENTIMETROS:");
                          scanf ("%f",&cm);
                          pulgacm(cm);
                          printf("\n...%f CENTIMETROS...\n",cm);
                          system("PAUSE"); 
                          break;
                     case 2:
                          printf ("INTRODUZCA LA CANTIDAD PARA CONVERTIR EN PULGADAS:");
                          scanf ("%f",&pulg);
                          cmapulg(pulg);
                          printf ("\n...%f PULGADAS...\n",pulg);
                          system("PAUSE"); 
                          break;
                     case 3:
                          printf ("\n.....GRACIAS POR USAR ESTE PROGRAMA\n.....QUE TENGA BUEN DIA..!\n");
                          break;                       
                     default:
                          printf("\n....OPCION INVALIDA....\n");
                          system("PAUSE");
                          }
                          }      
    
      
       
  
  system("PAUSE");	
  return 0;
}
float pulgacm (float a ){
      float pulg;
      pulg = a * 2.54;
      return pulg;
}
float cmapulg (float b ){
      float cm;
      cm = b /2.54;
      return cm;
}

