#include <cstdlib>
#include <iostream>


using namespace std;

float  centfahr ( float c);
float  fahrcent (float f );


int main(int argc, char *argv[])
{
    
      float            centigrados, fahr;
      int              opcion = 1;
    
    while ( opcion != 3 ) {
         
        printf ( "\n\n   Conversor de temperatura!!  \n\n\n" );   
        printf ( "\t    1. Centigrados a Fahrenheit    \n\n");
        printf ( "\t    2.  Fahrenheit a Centigrados \n\n");         
        printf ( "\t    3. Salir.  \n\n");
             
        printf ( "Elige una Opcion: " );
        scanf  ("%d",  &opcion); 
        
        switch( opcion )
        {
              case 1: 
                   cout << "\n Introduce un La temperatura en grados centigrados: ";
                   cin  >> centigrados;
                   fahr = centfahr (centigrados);
                   printf("\n\n %f grados centigrados equivalen a %f Fahrenheit!! \n\n ",centigrados, fahr );
                   system("PAUSE"); 
                   break;
              case 2: 
                   cout << "\n Introduce un La temperatura en grados Fahrenheit: ";
                   cin  >> fahr;
                   centigrados = fahrcent (fahr);
                   printf("\n\n %f grados Fahrenheit equivalen a %f Centigrados!! \n\n\n ", fahr,centigrados );
                   system("PAUSE"); 
                   break; 
                 case 3:
                  printf("Gracias por usar este programa!!\n\n\n\n");
                  break;                       
              default:
                  printf("\n\n\t\t Opcion Incorrecta!! \n\n\n\n");
                  system("PAUSE");
        } 
    }  
    
    system("PAUSE");
    return EXIT_SUCCESS;
}


float centfahr ( float cent  ){
     
     float fr;
     fr = cent * 9/5 + 32;
     return fr;
}


float fahrcent ( float fr  ){
     
     float cnt;
     cnt = (fr - 32) * 5 / 9;
     return cnt;
}
