#include <cstdlib>
#include <iostream>
#include <math.h>

using namespace std;
int hipotenusa ( int cata, int catb);

int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    int cat1;
    int cat2;
    int hipo,sum;
    int opcion=1;
    /* Datos de Entrada */
    while ( opcion!=2 ){
          printf ("\n\n   calculador de hipotenusas   \n\n");
          printf ("\t.....(1) para calcular la hipotenusa.\n");
          printf ("\t.....(2) salir del programa.\n");
          printf ("\n.....seleciona una opcion........\n");
          scanf ("%d",&opcion);
          switch (opcion){
          case 1:
    printf ("introduzca la primera cantidad del cateto 1:....");
    scanf ("%d", &cat1);
    
    printf ("introduzca la segunda cantidad del cateto 2:....");
    scanf ("%d", &cat2);
    hipo=hipotenusa(cat1,cat2);
      /* Datos de Salida */
    printf ("\n la hipotenusa = %d\n",hipo);
    
     system("PAUSE"); 
                   break;
          case 2:
               printf ("\n\n\n..........GRACIAS POR USAR ESTE PROGRAMA...........\n\n\n");
               break;
                 default:
                  printf("\n\n\t\t Opcion Incorrecta!! \n\n\n\n");
                  system("PAUSE");
                  }
                  }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
int hipotenusa (int cata,int catb){
    int hipo,sum;
    sum=(cata*cata)+(catb*catb);
    hipo=(int) sqrt(sum);

    return hipo;
}



