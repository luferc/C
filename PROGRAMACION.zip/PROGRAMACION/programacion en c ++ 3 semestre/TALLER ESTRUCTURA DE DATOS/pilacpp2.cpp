#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define  MAX   5

using namespace std;


bool meter ( char element );
bool imprimir ( );
bool pilaLlena ( );
bool pilaVacia ( );
bool sacar (  );
bool getLast (  );


char   pila[MAX];
int    tope = -1;
char   sacado;

int main(int argc, char *argv[])
{
    char           elemento;
    int            opcion = 1;
    
    while ( opcion != 7 ) {
         
        printf ( "\n\n    Implementacion de una pila con arreglos!!  \n\n\n" );   
        printf ( "\t    1. Meter.    \n\n");
        printf ( "\t    2. Sacar.   \n\n");
        printf ( "\t    3. Ver Ultimo Elemento Introducido. \n\n");
        printf ( "\t    4. Pila Vacia.    \n\n");
        printf ( "\t    5. Pila Llena.  \n\n");   
        printf ( "\t    6. Imprimir la Pila.  \n\n");           
        printf ( "\t    7. Salir.  \n\n");
             
        printf ( "Elige una Opcion: " );
        scanf  ("%d",  &opcion); 
        
        switch( opcion )
        {
              case 1: 
                   cout << "\n Introduce un caracter: ";
                   cin  >> elemento;
                   if ( !meter(elemento)){
                      printf("\n\n No se pudo insertar el elemento a la pila!! \n ");
                      printf(" La pila esta llena!! ");
                      system("PAUSE"); 
                   }
                   else {
                      printf(" El elemento se inserto a la pila \n\n");
                      system("PAUSE");
                   }
                   break;
                   
              case 2: 
                   if ( !sacar()){
                      printf(" No hay elementos en la pila!! \n ");
                      printf(" La pila esta Vacia!!  \n \n");
                      system("PAUSE"); 
                   }
                   else {
                      printf(" Un elemento fue sacado de la pila y es: %c \n\n", sacado);
                      system("PAUSE");
                   }
                   break;                  
              case 3:
                   if ( !getLast()){
                      printf(" \n\n No se pudo extraer ningun elemento de la pila!! \n ");
                      printf(" La pila esta Vacia!!  \n \n");
                      system("PAUSE"); 
                   }
                   else {
                      printf(" \n\nEl ultimo elemento de  la pila es: %c \n\n", sacado);
                      system("PAUSE");
                   }
                   break;       
              case 4: 
                   if ( pilaVacia() ){
                       printf("La pila esta Vacia!! \n\n");
                       system("PAUSE");
                   }
                   else{
                       printf("La pila No esta Vacia!!: \n\n"); 
                       system("PAUSE");
                   }                                    
                   break;           

              case 5: 
                   if ( pilaLlena() ){
                       printf("La pila esta Llena!! \n\n");
                       system("PAUSE");
                   }
                   else{
                       printf("La pila No esta Llena!!: \n\n");
                       system("PAUSE"); 
                   }
                   break;                                        
             
              case 6: 
              if (!imprimir() ){
                 printf("La pila esta Vacia \n\n");
                 system("PAUSE");
              }
              printf("\n\n");
              system("PAUSE");
              break;
              case 7:
                  printf("Gracias por usar este programa!!\n\n");
                  break;                       
              default:
                  printf("\n\n\t\t Opcion Incorrecta!! \n\n");
                   system("PAUSE");
        }
                      
   }                   
  
    system("PAUSE");
    return EXIT_SUCCESS;
}
bool meter ( char caracter ){
     
     if ( !pilaLlena () ){
          tope += 1;
          pila[tope] = caracter;
          return true;
     }
     else
         return false;
}
bool imprimir ( ){
     int i;
     if ( !pilaVacia () ){
          printf(" Contenido de la pila: \n\n" );
          for ( i = tope; i >= 0; i-- ){
              printf("\t\t\t | %c | \n", pila[i]);
              printf("\t\t\t  ___ \n");
          }
          return true;
     }
     else{
         printf("\t\t\t |  | \n");
         printf("\t\t\t  ___ \n");
         return false;
     }
}
bool pilaLlena ( ){
     
     if ( tope + 1 == MAX )

          return true;
     else
         return false;
}
bool pilaVacia ( ){
     
     if ( tope  == -1 )

          return true;
     else
         return false;
}
bool sacar (  ){
     
     if ( !pilaVacia () ){
          
          sacado = pila[tope];
          tope -= 1;
          return true;
     }
     else
         return false;
}
bool getLast (  ){
     char caracter;
     if ( !pilaVacia () ){
          
          sacado = pila[tope];
          return true;
     }
     else
         return false;
}

