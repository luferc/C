#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define  MAX   5

using namespace std;

bool meter ( char element );
bool imprimir ( );
bool pilaLlena ( );
bool pilaVacia ( );
bool sacar (  );
bool getLast (  );

char   pila[MAX];
int    tope = -1;
char   sacado;


int main(int argc, char *argv[])
{
       char           elemento;
       int i;
       cout<< "\t\t �����������������������\n";
       cout<< "\t\t �                     �\n";
       cout<< "\t\t �(( a + b)-( c x d )) �\n";
       cout<< "\t\t �                     �\n";
       cout<< "\t\t �����������������������\n";
        
       cout << "\n Introduce un caracter: ";
       for (i=1;i<12;i++)
       {
                   cin  >> elemento;
                   if ( !meter(elemento))
                   {
                      printf("\n\t\t PILA AL LIMITE \n");
                      printf("\t\t ELIMINE DATOS \n");
                          }
                   else {
                      printf("\n\t\t LISTO \n");
                   }
                   }
                   if (!imprimir() )
                   {
                 printf("\n\t\t PILA VACIA \n");
                 system("PAUSE");
              }
              printf("\n\n");
              system("PAUSE");
              
                   if ( !sacar())
                   {
                      printf("\n\n NO HAY DATOS \n");
                      printf("\n");
                      system("PAUSE"); 
                   }
                   else 
                   {
                      printf("\n\t\t FUERA: %c \n", sacado);
                      system("PAUSE");
                   }
                   if ( !getLast()){
                      printf(" \n\n No se pudo extraer ningun elemento de la pila!!  \n");
                      printf(" La pila esta Vacia!!  \n \n");
                      system("PAUSE"); 
                   }
                   else {
                      printf(" \n\nEl ultimo elemento de  la pila es: %c \n\n", sacado);
                      system("PAUSE");
                   }
                   if ( pilaVacia() ){
                       printf("La pila esta Vacia!! \n\n");
                       system("PAUSE");
                   }
                   else{
                       printf("La pila No esta Vacia!!: \n\n"); 
                       system("PAUSE");
                   }                                    
                   if ( pilaLlena() ){
                       printf("La pila esta Llena!! \n\n");
                       system("PAUSE");
                   }
                   else{
                       printf("La pila No esta Llena!!: \n\n");
                       system("PAUSE"); 
                   }
                   
    system("PAUSE");
    return EXIT_SUCCESS;
}
bool meter ( char elemento )
{
     if ( !pilaLlena () )
     {
          tope += 1;
          pila[tope] = elemento;
          return true;
          }
     else
         return false;
}
bool imprimir ( )
{
     int i;
     if ( !pilaVacia () )
     {
          printf("\n\t CONTENIDO DE LA PILA \n");
          for ( i = tope; i >= 0; i-- )
          {
              printf("\t\t\t ECUACION \n");
              printf("\t\t\t  %c ", pila[i]);
          }
          return true;
     }
     else
     {
         printf("\t\t\t ECUACION \n");
         printf("\t\t\t  ( ) \n");
         return false;
     }
}
bool pilaLlena ( )
{
     if ( tope + 1 == MAX )
     return true;
     else
     return false;
}
bool pilaVacia ( )
{
     if ( tope  == -1 )
     return true;
     else
     return false;
}
bool sacar (  )
{
     if ( !pilaVacia () )
     {
          sacado = pila[tope];
          tope -= 1;
          return true;
     }
     else
         return false;
}
bool getLast (  )
{
     char caracter;
     if ( !pilaVacia () )
     {
          sacado = pila[tope];
          return true;
     }
     else
         return false;
}
