/* PROGRAMA SIMULACION DE UNA COLA */
/* TALLER DE ESTRUCTURA DE DATOS */
#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define  MAX   5

using namespace std;
/* FUNCIONES */
bool ingresar(char a);
bool despachar();
bool imprimir();
bool pilaLlena();
bool pilaVAcia();
bool getLast (  );
char pila[MAX];
int    tope = -1;
char   fuera;

int main(int argc, char *argv[])
/* PROGRAMA PRINCIPAL MAIN */
{
            /* DECLARACION DE VARIABLES */
            char elemento;
            int op=1;
            /* DATOS DE ENTRADA */
              printf("\n\t (1)...INGRESAR\n");
              printf("\n\t (2)...IMPRIMIR\n");
              printf("\n\t (3)...DESPACHAR\n");
              printf("\n\t (4)...ULTIMO DATO INGRESADO\n");
              printf("\n\t (5)...SALIR\n");
              printf("\n\n\t SELECCIONE UNA OPCION:   ");
              scanf("%i",&op);
              system("cls");// Limpia pantalla.
              
              /* DATOS DE SALIDA */
              switch (op)
              {
                     case 1:// INGRESAR
                      printf("\n\n\t ** INGRESAR DATOS **\n");
                      printf("\n\n\t INGRESE AQUI:  ");
                      scanf("%i",&elemento);
                      if(!ingresar(elemento))
                      {
                                          printf("\n\t   PILA    \n");
                                          printf("\n\t AL LIMITE \n");
                                          }//fIN DE IF.
                                          else
                                          {
                                              printf("\n\t   LISTO   \n");
                                              printf("\n\t   DATO    \n");
                                              printf("\n\t INGRESADO \n");
                                              }//Fin de else.
                                              break;
                                              case 5:
                                                   printf("\t �����������\n");
                                                   printf("\t �   FIN   �\n");
                                                   printf("\t �����������\n");
                                                   printf("\n\n\t BY:...FERNANDO CERVANTES...!\n\n");
                                                   break;
                                                   default://default. 
                                                   printf("\n\n\t   ERROR     \n");  
                                                   printf("\n\n\t   OPCION    \n");
                                                   printf("\n\n\t  INCORRECTA \n");

                                               }//Fin de Switch.
          
         
    
    system("PAUSE");
    return EXIT_SUCCESS;
}//FIN DE MAIN.

/* LLAMAR FUNCIONES */
bool ingresar(char caracter)//Funcion Ingresar.
{
     if ( !pilaLlena () )
     {
          tope += 1;
          pila[tope] = caracter;
          return true;
          }
          else
          return false;
}
bool pilaLlena ( )//Funcion Pila Max.
{
     if ( tope + 1 == MAX )
     return true;
     else
     return false;
     }
bool pilaVacia ( )//Funcion Pila Vacia.
{
     if ( tope  == -1 )
     return true;
     else
     return false;
     }
bool imprimir ( )//Funcion Imprimir pila.
{
     int i;
     if ( !pilaVacia () )
     {
          printf("\n\t IMAGEN DE LA PILA:\n" );
          for ( i = tope; i >= 0; i-- )
          {
              printf("\t\t ���������\n");
              printf("\t\t �       �\n");
              printf("\t\t �   %c   �\n", pila[i]);
              printf("\t\t �       �\n");
              printf("\t\t ���������\n");
          }//Fin de For.
          return true;
     }//Fin de if.
     else{
          printf("\t\t ����� \n");
          printf("\t\t �   � \n");
          printf("\t\t ����� \n");
          printf("\t\t �   � \n");
          printf("\t\t ����� \n");
          printf("\t\t �   � \n");
          printf("\t\t ����� \n");
          printf("\t\t �   � \n");
          printf("\t\t ����� \n");
          return false;
     }//Fin de Else.
}
bool despachar (  )//Funcion Sacar.
{
     if ( !pilaVacia () )
     {
          fuera = pila[tope];
          tope -= 1;
          return true;
          }
          else
          return false;
          }
bool getLast (  )//Funcion Mostrar ultimo dato.
{
     char caracter;
     if ( !pilaVacia () )
     {
          fuera = pila[tope];
          return true;
          }
          else
          return false;
          }

