// LIBRERIAS:
#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define  MAX   5
using namespace std;
// FUNCIONES:
bool meter (int elementoB, int *, int *);
bool pilaLlena(int *);
bool imprimir ( int *pila, int *tope);
bool pilaVacia( int *tope);
bool sacar    (int *pila, int *tope, int *opr  );

int main(int argc, char *argv[])
{// INICIO MAIN:
    // DECLARACION DE VARIABLES:
    int pila1[MAX];// PILA NUMERO UNO.
    int pila2[MAX];// PILA NUMERO DOS.
    int pilat[MAX];// PILA RESULTADO.
    int carry,sp1,sp2,spres,elementoA,op,tmax,opA,opB,resta,minimo;
    int t1=-1,t2=-1,tres=-1;
    // DATOS DE ENTRADA:
    while(op!=4)
    {// INICIO WHILE.
    printf("\n\n\n");
    printf("\t\t (1)...PILA UNO   \n");
    printf("\t\t (2)...PILA DOS   \n");
    printf("\t\t (3)...IMPRIMIR   \n");
    printf("\t\t (4)...SUMA  TOTAL\n");
    printf("\t\t (5)...RESTA TOTAL\n");
    printf("\t\t (6)...SALIR      \n");
    printf("\t\t SELECCIONE:  ");
    scanf("%i",&op);
    system("cls");// Limpia pantalla.
    switch(op)
    {// INICIO SWITCH.
    case 1: // PILA UNO.
    printf("\n\t INGRESE LOS VALORES: ");
    scanf("%i",&elementoA);
    if(!meter(elementoA,&t1,pila1))
    {
                                       printf("\n\t PILA LLENA \n");
                                       printf("\n\n");
                                       }
                                       else
                                       {
                                           printf("\n\t LISTO \n");
                                           printf("\n\t ELEMENTO INSERTADO \n");
                                           }
                                           break;
                                           case 2:
                                                printf("\n\t INGRESE LOS VALORES: ");
                                                scanf("%i",&elementoA);
                                                if(!meter(elementoA,&t2,pila2))
                                                {
                                                    printf("\n\t PILA LLENA \n");
                                                    printf("\n\n");
                                                    }// FIN IF.
                                                    else
                                                    {
                                                      printf("\n\t LISTO \n");
                                                      printf("\n\t ELEMENTO INSERTADO \n");
                                                      }//  FIN ELSE.
                                                      break;
                                                      case 3:
                                                           printf("\n\t\t PILA --> 1 \n");
                                                           if (!imprimir(pila1, &t1) )
                                                           {
                                                                                printf("\n\t\t PILA VACIA \n");
                                                                                }
                                                                                printf("\n\t\t PILA --> 2 \n"); 
                                                                                if (!imprimir(pila2, &t2) )
                                                                                {
                                                                                                     printf("\n\t\t PILA VACIA \n");
                                                                                                     }
                                                                                                     break;
                                                                                                     case 4:// SUMA DE LAS PILAS A + B
                                                                                                          tmax = t1;
                                                                                                          if(t2 > tmax)
                                                                                                          tmax = t2;
                                                                                                          carry = 0;
                                                                                                          for ( int i = tmax; i >= 0; i-- )
                                                                                                          {
                                                                                                              if ( !sacar( pila1, &t1, &opA))
                                                                                                              {
                                                                                                                   printf("\n\t\t PILA VACIA \n");
                                                                                                                   opA = 0;
                                                                                                                   }// FIN IF.
                                                                                                                   if(!sacar( pila2,&t2,&opB))
                                                                                                                   {
                                                                                                                        printf("\n\t\t PILA VACIA\n");
                                                                                                                        opB = 0;
                                                                                                                        }
                                                                                                                        resta = opA + opB + carry;
                                                                                                                        if ( resta > 10 )
                                                                                                                        {
                                                                                                                             carry = 1;
                                                                                                                             resta = resta - 10;
                                                                                                                             }
                                                                                                                             else
                                                                                                                             carry = 0;
                                                                                                                             // Introduce el resultado obtenido  a la pila de resultados
                                                                                                                             if ( !meter(resta, &tres,pilat))
                                                                                                                             {
                                                                                                                                  printf("\t\t LA PILA \n ");
                                                                                                                                  printf("\t\t ESTA LLENA");
                                                                                                                                  }
                                                                                                                                  else {
                                                                                                                                       printf("\n\t\t       LISTO       \n");
                                                                                                                                       printf("\n\t\t ELEMENTO INSERTADO\n");
                                                                                                                                       }// FIN ELSE
                                                                                                                                       }// FIN IF
                                                                                                                                       if ( carry > 0 ) 
                                                                                                                                       {
                                                                                                                                            resta = 1;
                                                                                                                                            if ( !meter(resta, &tres,pilat))
                                                                                                                                            {
                                                                                                                                               printf("\t\t LA PILA \n ");
                                                                                                                                               printf("\t\t ESTA LLENA");
                                                                                                                                                 }
                                                                                                                                                 else 
                                                                                                                                                 {
                                                                                                                                                     printf("\n\t\t       LISTO       \n");
                                                                                                                                                     printf("\n\t\t ELEMENTO INSERTADO\n");
                                                                                                                                                      }// FIN ELSE
                                                                                                                                                      }// FIN IF
                                                                                                                                                      break;
                                                                                                                                                      case 5:// RESTA LAS PILAS. A - B
                                                                                                                                                      carry = 0;
                                                                                                                                                      for ( int i = t1; i >= 0; i-- )
                                                                                                                                                      {
                                                                                                                                                          if ( !sacar( pila1,&t1,&opA))
                                                                                                                                                          {
                                                                                                                                                               printf("\n\t\t PILA VACIA \n");
                                                                                                                                                               opA = 0;
                                                                                                                                                               }// FIN IF
                                                                                                                                                               if ( !sacar( pila2,&t2,&opB))
                                                                                                                                                               {
                                                                                                                                                                    printf("\n\t\t PILA VACIA \n");
                                                                                                                                                                    opB = 0;
                                                                                                                                                                    }
                                                                                                                                                                    minimo = opB + carry;
                                                                                                                                                                    if ( opA >= minimo )
                                                                                                                                                                    {
                                                                                                                                                                         resta = opA - minimo;
                                                                                                                                                                         carry = 0;
                                                                                                                                                                         }
                                                                                                                                                                         else 
                                                                                                                                                                         {
                                                                                                                                                                              opA = opA + 10;
                                                                                                                                                                              resta = opA - minimo;
                                                                                                                                                                              carry = 1;
                                                                                                                                                                              }
                                                                                                                                                                              // Introduce el resultado obtenido  a la pila de resultados
                                                                                                                                                                              if ( !meter(resta,&tres,pilat))
                                                                                                                                                                              {
                                                                                                                                                                                  printf("\t\t LA PILA \n ");
                                                                                                                                                                                  printf("\t\t ESTA LLENA");
                                                                                                                                                                                   }
                                                                                                                                                                                   else 
                                                                                                                                                                                   {
                                                                                                                                                                                         printf("\n\t\t       LISTO       \n");
                                                                                                                                                                                         printf("\n\t\t ELEMENTO INSERTADO\n");
                                                                                                                                                                                        }// FIN ELSE
                                                                                                                                                                                        } //for 
                                                                                                                                                                                        break;
                                                                                                                                                                                        case 6:// SALIR
                                                                                                                                                                                        printf("\n\n\t\t\t FIN \n\n");
                                                                                                                                                                                        break;
                                                                                                                                                                                        default:
                                                                                                                                                                                                printf(" ERROR");        
                                                                                                                                                                                                }// FIN SWITCH.
    system("PAUSE");
    system("cls");
    }// FIN WHILE.
    return EXIT_SUCCESS;
}//FIN MAIN.

// LLAMADO DE FUNCIONES:
bool meter(int elementoC, int *pila, int *tope)
{
        if(!pilaLlena(tope))
        {
                            *tope+=1;
                            pila[*tope] = elementoC;
                         return true;
                         }// FIN IF.
                         else
                         return false;
                         }// FIN INGRESAR.
                         
bool imprimir(int *pila, int *tope)
{ 
     int i;
     if(!pilaLlena(tope))
     {
                         for(i=*tope; i >= 0; i--)
                         {
                                      printf("\t\t . %i . \n",pila[i]);
                                      printf("\t\t ...... \n");
                                      }// FIN FOR
                                      return true;
                                      }// FIN IF.
                                      else
                                      {
                                          printf("\t\t .    . \n");
                                          printf("\t\t ...... \n");
                                          return false;
                                          }// FIN ELSE
                                          }// FIN IMPRIMIR.
bool pilaVacia ( int *tope)
{  
     if ( *tope  == -1 )
          return true;
     else
         return false;
}
bool sacar (int *pila, int *tope, int *opr  )
{ 
     if ( !pilaVacia (tope) )
     {   
          *opr = pila[*tope];
          *tope -= 1;
          return true;
     }
     else
         return false;
}
