#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    /* Declaracion de variables */
    int i,a=1;
    float dife[12],lluvia[12];
    float promedio,suma=0,max=0,min=0,me,rest;
    /* Datos de Entrada */
    printf ("\n\n PROGRAMA METEROLOGICO PARA SACAR EL PROMEDIO ANUAL DE LLUVIA \n\n");
    printf ("\t INTRODUZCA EL PROMEDIO TOTAL DE LLUVIA PARA CADA MES: \n");
    for (i=0;i<12;i++){
        scanf ("%f",&me);
        lluvia [i]=me;
        suma=suma+lluvia[i];
        }
        promedio=suma/12;
       for (i=0;i<12;i++)
       {
           printf ("%.2f\n",lluvia[i]);
        }
                                              
                                              
    /* Datos de Salida */
    printf("\n\n");
    printf ("\n\t PROMEDIO TOTAL = %.2f",promedio);
    printf ("\n\t SUMA           = %.2f",suma);
                                                  
     for(i=0;i<12;i++)
     {            
                  if((lluvia[i]>max)||(i==0))  
                  max=lluvia[i];
     }         
        printf ("\n\t VALOR MAXIMO   = %.2f ",max);
        for (i=0;i<12;i++){
            if ((lluvia[i]<min)||(i==0))
            min=lluvia[i];
            }
            printf ("\n\t VALOR MINIMO   = %.2f ",min);
            for (i=0;i<12;i++){
                rest=lluvia[i]-promedio;
                dife[i]=rest;
                }
                for(i=0;i<12;i++){
                                  printf("\n  DIFERENCIA DEL MES [%d] =  %.2f \n",a,dife[i]);
                                  a++;
                                  }
                
                
        
    system("PAUSE");
    return EXIT_SUCCESS;
}
