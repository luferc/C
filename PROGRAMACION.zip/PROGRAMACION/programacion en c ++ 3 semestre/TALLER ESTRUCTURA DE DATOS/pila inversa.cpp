#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define  MAX   5

using namespace std;
// FUNCIONES
bool meter ( char caracter,int *,char * );
bool imprimir ( int *, char *);
bool sacar (int *, char*);
bool pilaVacia (int *);
char sacado;
int main(int argc, char *argv[])
{
    // DECLARACION DE VARIABLES
    int tope = -1,tope1=-1,tope2=-1,op;
    char pila[MAX],p1[MAX],p2[MAX],a;
    // DATOS DE ENTRADA
    while ( op!= 4 )
     { 
        printf("\n\t (1)...INGRESAR\n");
        printf("\n\t (2)...INVERTIR DATOS\n");
        printf("\n\t (3)...IMPRIMIR\n");
        printf("\n\t (4)...SALIR\n");
        printf("\n\n\t SELECCIONE UNA OPCION:  ");
        scanf("%i",&op);
        system("cls");// Limpia pantalla.
        
        switch( op )
        {
              case 1: 
    
                     printf("\n\n\t INGRESE:  ");
                     cin>>a;
                     if (meter(a,&tope,pila)){
                         printf("\n\n\t LISTO \n");
                     }
                   else{
                        printf("\n\n\n");
                        printf("\t    �������������������\n");
                        printf("\t    �  PILA AL LIMITE �\n");
                        printf("\t    �        :(       �\n");
                        printf("\t    �������������������\n");
                                               
                        }
               break;
               
               case 2:
                    for(int i=tope;i >= 0;i--)
                    {
                            if (sacar(&tope,pila) )
                            {
                              meter(sacado,&tope1,p1);
                           }
                       }
                     // printf("\n\n\t PILA PRINCIPAL \n");
                      //imprimir(&tope,pila);
                      printf("\n\n\t PILA AUXILIAR # -> 1 \n");
                      imprimir(&tope1,p1);
                      //printf("\n\n\t PILA AUXILIAR #->  2 \n");
                      //imprimir(&tope2,p2);
                     for(int i =tope1;i >= 0;i--)
                     {
                     if (sacar(&tope1,p1) )
                     {
                     meter(sacado,&tope2,p2);
                           }
                       }
                      //printf("\n\n\t PILA PRINCIPAL \n");
                      //imprimir(&tope,pila);
                      //printf("\n\n\t PILA AUXILIAR # -> 1 \n");
                      //imprimir(&tope1,p1);
                      printf("\n\n\t PILA AUXILIAR # -> 2 \n");
                      imprimir(&tope2,p2);
                     for(int i =tope2;i >= 0;i--)
                     {
                         if (sacar(&tope2,p2) )
                         {
                             meter(sacado,&tope,pila);
                          }
                      }
                      printf("\n\n\t PILA PRINCIPAL \n");
                      imprimir(&tope,pila);
                      //printf("\n\n\t PILA AUXILIAR # -> 1 \n");
                      //imprimir(&tope1,p1);
                      //printf("\n\n\t PILA AUXILIAR # -> 2 \n");
                      //imprimir(&tope2,p2);              
                      break; 
                      case 3:
                           if (imprimir(&tope,pila) )
                           {
                           printf("\n\n\t PILA ESTANDAR\n");
                           printf("\n\n\n\n");
                           }
                           break;
                           case 4:
                                
                                printf("\n\n\n\n");
                                printf("\t �����������\n");
                                printf("\t �   FIN   �\n");
                                printf("\t �����������\n");
                                printf("\n\n\t BY:...FERNANDO CERVANTES...!\n\n");
                                printf("\n\n\n\n");
                                break;
                                default://default. 
                                printf("\n\n\t   ERROR     \n");  
                                printf("\n\n\t   OPCION    \n");
                                printf("\n\n\t  INCORRECTA \n");
                                }//Fin de Switch.                
  system("PAUSE");
  system("cls");
  } // Fin de While.
  return EXIT_SUCCESS;
  }// fin de main.

bool meter ( char caracter,int *tope,char *pila  ){
     if ( *tope<=MAX ){
          *tope+=1;
          pila[*tope] = caracter;
          return true;
      }
     else{
     printf("\n\n\t PILA LLENA \n");
      return false;
      }
}
bool imprimir ( int *tope, char *pil){
     int i;
     if ( pilaVacia (tope)){
          for ( i = *tope; i >= 0; i-- ){
              printf("\t\t ���������\n");
              printf("\t\t �       �\n");
              printf("\t\t �   %c   �\n", pil[i]);
              printf("\t\t �       �\n");
              printf("\t\t ���������\n");
              }
              return true;
              }
              else
              {
                  printf("\n\n\n\n");
                  printf("\t\t ����� \n");
                  printf("\t\t �   � \n");
                  printf("\t\t ����� \n");
                  printf("\t\t �   � \n");
                  printf("\t\t ����� \n");
                  printf("\t\t �   � \n");
                  printf("\t\t ����� \n");
                  printf("\t\t �   � \n");
                  printf("\t\t ����� \n");
                  return false;
                  }
                  }
bool sacar (int *tope, char *pi){
    
    if ( *tope<=MAX ){
         
           sacado = pi[*tope];
           *tope -= 1;

           return true;
      }
     else
        return false;
}
bool pilaVacia ( int *tope ){
     
     if ( *tope  > -1 )

          return true;
     else
         return false;
}
