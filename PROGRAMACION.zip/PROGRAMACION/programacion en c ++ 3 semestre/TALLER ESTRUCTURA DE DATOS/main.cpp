#include <cstdlib>
#include <iostream>

using namespace std;
float pulgacm (float a);
float cmapulg (float b);

int main(int argc, char *argv[])
{
    /*Declaracion de Variables*/
    float pulg;
    float cm;
    int opcion=1;
    /*Datos de Entrada*/
    printf ("********************************************************************************\n*********************PROGRAMA CONVERTIDOR DE UNIDADES***********************************************************************************************************\n");
        while ( opcion !=3 ){
              printf ("........................MENU..........................\n");
              printf ("\t     (1)....PULGADAS A CENTIMETROS\n");
              printf ("\t     (2)....CENTIMETROS A PULGADAS\n");
              printf ("\t     (3)....SALIR DEL PROGRAMA\n");
              printf ("SELECCIONE UNA OPCION:");
              scanf ("%d",&opcion);
              switch (opcion)
              {
                     /*Datos de Salida*/
                     case 1:
                          printf ("INTRODUZCA LA CANTIDAD PARA CONVERTIR EN CENTIMETROS:");
                          scanf ("%f",&cm);
                          cm=pulgacm(pulg);
                          printf("\n...%f CENTIMETROS...\n",cm);
                          system("PAUSE"); 
                          break;
                     case 2:
                          printf ("INTRODUZCA LA CANTIDAD PARA CONVERTIR EN PULGADAS:");
                          scanf ("%f",&pulg);
                          pulg=cmapulg(cm);
                          printf ("\n...%f PULGADAS...\n",pulg);
                          system("PAUSE"); 
                          break;
                     case 3:
                          printf ("\n.....GRACIAS POR USAR ESTE PROGRAMA\n.....QUE TENGA BUEN DIA..!\n");
                          break;                       
                     default:
                          printf("\n....OPCION INVALIDA....\n");
                          system("PAUSE");
                          }
                          }      
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
float pulgacm (float pul ){
      float pul;
      pul = cm * 2.54;
      return pul;
}
float cmapulg (float cm){
      float cm;
      pulg = cm /2.54;
      return cm;
}
