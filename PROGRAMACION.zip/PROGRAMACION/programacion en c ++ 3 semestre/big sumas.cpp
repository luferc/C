#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define  MAX   5

using namespace std;

// Prototipo de las funciones

bool meter ( int entero,int *, int *);
bool pilaLlena (int * );
bool imprimir ( int *pila, int *tope);
bool pilaVacia ( int *tope);
bool sacar (int *pila, int *tope, int *opr  );
bool getLast (int *pila,  int *tope, int *opr );


int main(int argc, char *argv[])
{
    int            elemento, op1,op2, res, tmax, carry, min;
    int            opcion = 1;
    int            pop1[MAX];
    int            pop2[MAX];
    int            pres[MAX];
    int            top1  = -1;
    int            top2 = -1;
    int            tres = -1;
    char           sacado;
    
    while ( opcion != 10 ) {
         
        printf ( "\n\n    Suma de enteros muy grandes!!  \n\n\n" );   
        printf ( "\t    1. Obtener el Operando uno.    \n\n");
        printf ( "\t    2. Obtener el Operando dos.    \n\n");
        printf ( "\t    3. Imprimir los operandos.  \n\n");  
        printf ( "\t    4. Calcular la suma.    \n\n");
        printf ( "\t    5. Calcular la resta.    \n\n");        
        
                   
        printf ( "\t    9. Imprimir el resultado.  \n\n");           
        printf ( "\t   10. Salir.  \n\n");
             
        printf ( "Elige una Opcion: " );
        scanf  ("%d",  &opcion); 
        
        switch( opcion )
        {
              case 1: 
                   cout << "\n Introduce un entero: ";
                   cin  >> elemento;
                   if ( !meter(elemento, &top1, pop1 )){
                      printf("\n\n No se pudo insertar el elemento a la pila!! \n ");
                      printf(" La pila esta llena!! ");
                      system("PAUSE"); 
                   }
                   else {
                      printf(" El elemento se inserto a la pila \n\n");
                      system("PAUSE");
                   }
                   break;
                   
              case 2: 
                   cout << "\n Introduce un Entero: ";
                   cin  >> elemento;
                   if ( !meter(elemento, &top2, pop2 )){
                      printf("\n\n No se pudo insertar el elemento a la pila!! \n ");
                      printf(" La pila esta llena!! ");
                      system("PAUSE"); 
                   }
                   else {
                      printf(" El elemento se inserto a la pila \n\n");
                      system("PAUSE");
                   }
                   break;
              case 3:
                   // Imprime Los operandos op1 y op2
                   printf("\t\t   Opernado1 \n\n"); 
                   if (!imprimir(pop1,  &top1) ){
                       printf("\n\t\t La Pila op1 esta Vacia \n\n\n\n");
                  
                   }
                   printf("\n\n\n\t\t   Operando2 \n\n"); 
                   if (!imprimir(pop2,  &top2) ){
                      printf("\t\t La pila op2 esta Vacia \n\n\n\n");
                   }
                   break; 
                   
              case 4:
                   
                   // Verifica cual es el tope mas grande de las dos pilas
                   // Para iterar sobre el!!
                   tmax = top1;
                   if ( top2 > tmax )
                      tmax = top2;
                   // Obtiene la suma de las dos pilas
                   carry = 0;
                   for ( int i = tmax; i >= 0; i-- ){
                       
                       if ( !sacar( pop1, &top1, &op1)){
                          printf(" La pila esta Vacia!!  \n\n");
                          op1 = 0;

                       }
                       if ( !sacar( pop2, &top2, &op2)){
                          printf(" La pila esta Vacia!!  \n\n");
                          op2 = 0;

                       }
                       res = op1 + op2 + carry;
                       if ( res > 9 ){
                            carry = 1;
                            res = res - 10;
                       }
                       else
                         carry = 0;
                       // Introduce el resultado obtenido  a la pila de resultados
                       if ( !meter(res, &tres, pres )){
                           printf("\n\n No se pudo insertar el elemento a la pila!! \n ");
                           printf(" La pila esta llena!! ");
                           system("PAUSE"); 
                       }
                       else {
                           printf(" El elemento se inserto a la pila \n\n");

                       }
                   }
                   if ( carry > 0 ) {
                        res = 1;
                       if ( !meter(res, &tres, pres )){
                           printf("\n\n No se pudo insertar el elemento a la pila!! \n ");
                           printf(" La pila esta llena!! ");
                           system("PAUSE"); 
                       }
                       else {
                           printf(" El elemento se inserto a la pila \n\n");

                       }                        
                   }   
                   break;
                   
                   
              case 5:
                   

                   // Obtiene la resta de las dos pilas
                   carry = 0;
                   for ( int i = top1; i >= 0; i-- ){
                       
                       if ( !sacar( pop1, &top1, &op1)){
                          printf(" La pila esta Vacia!!  \n\n");
                          op1 = 0;

                       }
                       if ( !sacar( pop2, &top2, &op2)){
                          printf(" La pila esta Vacia!!  \n\n");
                          op2 = 0;

                       }
                       min = op2 + carry;
                       if ( op1 >= min ){                            
                            res = op1 - min;
                            carry = 0;
                       }                       
                       else {
                         op1 = op1 + 10;
                         res = op1 - min;
                         carry = 1;
                       }
                       // Introduce el resultado obtenido  a la pila de resultados
                       if ( !meter(res, &tres, pres )){
                           printf("\n\n No se pudo insertar el elemento a la pila!! \n ");
                           printf(" La pila esta llena!! ");
                           system("PAUSE"); 
                       }
                       else {
                           printf(" El elemento se inserto a la pila \n\n");

                       }
                   } //for
 
                   break;               
             case 9:
                   // Imprime la pila de resultado
                   printf("\n\n\t\t\t Resultado \n\n"); 
                   if (!imprimir(pres,  &tres) ){
                       printf("\n\t\t La Pila de resultado esta Vacia \n\n\n\n");
                  
                   }
                   tres = -1;
                   break;  
              case 10:
                  printf("Gracias por usar este programa!!\n\n");
                  break;                                             
              default:
                  printf("\n\n\t\t Opcion Incorrecta!! \n\n\n\n");
                  system("PAUSE");
        }
                      
   }                   
  
    system("PAUSE");
    return EXIT_SUCCESS;
}
bool meter ( int entero, int *tope,int *pila ){
     
     if ( !pilaLlena ( tope ) ){
          *tope += 1;
          pila[*tope] = entero;
          return true;
     }
     else
         return false;
}

bool imprimir ( int *pila, int *tope){
     int i;
     if ( !pilaVacia ( tope ) ){
          //printf(" Contenido de la pila: \n\n" );
          for ( i = *tope; i >= 0; i-- ){
              printf("\t\t\t | %d | \n", pila[i]);
              printf("\t\t\t  ___ \n");
          }
          return true;
     }
     else{
         printf("\t\t\t |  | \n");
         printf("\t\t\t  __ \n");
         return false;
     }
}

bool pilaLlena ( int *tope ){
     
     if ( *tope + 1 == MAX )

          return true;
     else
         return false;
}

bool pilaVacia ( int *tope){
     
     if ( *tope  == -1 )

          return true;
     else
         return false;
}

bool sacar (int *pila, int *tope, int *opr  ){
     
     if ( !pilaVacia (tope) ){
          
          *opr = pila[*tope];
          *tope -= 1;
          return true;
     }
     else
         return false;
}

bool getLast (int *pila,  int *tope, int *opr ){
     char caracter;
     if ( !pilaVacia (tope) ){
          
          *opr = pila[*tope];
          return true;
     }
     else
         return false;
}

