#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
int pares [ 5 ];
int nones [ 5 ];
int x,n,p=0,par=0,non=0,no=0;
int contador,almacena;
 

printf ("\n...INTRODUZCA LOS NUMEROS PARA SEPARARLOS EN PARES Y NONES...\n");
for (contador=0;contador<=5;contador++){
for (n=0;n<=5;n++){
     scanf ( "%d",&x );
         
    if ( x%2==0 ){
         pares [ p ]=x;
         par++;
         p++;
         }
         else{
         nones [ no ]=x;
         non++;
         no++;}
         }
         if (pares[n]>pares[n+1]){
                                  almacena=pares[n];
                                  pares[n]=pares[n+1];
                                  pares[n+1]=almacena;
                                  }
         if (nones[n]>nones[n+1]){
                                  almacena=nones[n];                         
                                  nones[n]=nones[n+1];
                                  nones[n+1]=almacena;
                                  }
         for (p=0;p<par;p++){
             printf ("los pares: %d\n", pares [ p ]);
            
             }
             for (no=0;no<non;no++){
                 printf("los nones: %d\n",nones [ no ]);
                 }
                  if ( par>n ){
         printf ("%d es el orden de mayor a menor\n",pares[n]);
         }
    if (non>n){
               printf("%d es el orden de mayor a menor\n",nones[n]);
               }
               }
  system("PAUSE");	
  return 0;
}
