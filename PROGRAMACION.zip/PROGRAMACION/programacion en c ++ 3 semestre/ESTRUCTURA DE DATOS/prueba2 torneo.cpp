#include <cstdlib>
#include <iostream>
#include <time.h>

using namespace std;

int main(int argc, char *argv[])
{
    int eki[2][8];
    int juego,resul,op1,op2;
    int opcion=1;
    while ( opcion !=9 )
    {
    printf("\t\t��������������������������\n");
    printf("\t\t�                        �\n");
    printf("\t\t�   CUP INTER-CLUB 2009  �\n");
    printf("\t\t�                        �\n");
    printf("\t\t��������������������������\n\n\n");
         
              printf("*********** SELECCIONE LOS EQUIPOS **********\n");
              printf("***********          ..VS..        **********\n");
              printf("\t     (1).....CHIVAS\n");
              printf("\t     (2).....MANCHESTER UNTD.\n");
              printf("\t     (3).....BARCELONA\n");
              printf("\t     (4).....GALAXI\n");
              printf("\t     (5).....RIVER\n");
              printf("\t     (6).....ARSENAL\n");
              printf("\t     (7).....CHELSEA\n");
              printf("\t     (8).....LIVERPOOL\n");
              printf("\t     (9).....SALIR\n");
              printf("\n\n\t EQUIPO: ");
              scanf("%i",&op1);
              printf("\n\n\t EQUIPO: ");
              scanf("%i",&op2);
                if (op1==9 && op2==9) break;
              system("cls");
              srand(time(NULL));
    for  (juego=1;juego<=1;juego++)
          {
          printf("\t\t   ��������������������������\n");
          printf("\t\t   �                        �\n");
          printf("\t\t   �  [1] GANA   = 3 PTS.   �\n");
          printf("\t\t   �  [2] EMPATA = 1 PTS.   �\n");
          printf("\t\t   �  [3] PIERDE = 0 PTS.   �\n");
          printf("\t\t   �                        �\n");
          printf("\t\t   ��������������������������\n");
          printf("\n\n\t\t %i VS %i ",op1,op2);
         //++eki[0][juego];
         resul = 1 + rand() % 3; // numero aleatorio del 1 a 3.
         eki[0][juego]=resul;  // Asignar datos
         
         if (eki[0][juego]==1)
         eki[1][juego]=3;
         if (eki[0][juego]==2)
         eki[1][juego]=1;
         if (eki[0][juego] ==3)
         eki[1][juego]=0;
         //if (eki[0][juego]==2)
         //eki[1][juego]=1;
         printf ("\n\t\t [%i]\n\t\t  %i PUNTOS.\n",eki[0][juego],eki[1][juego]);
         //if(eki[1][juego]>op1&&op2==3)
         printf("\t\t %i GANA\n",op1);
         //if(eki[1][juego]<op1&&op2==0)
         printf("\t\t %i PIERDE\n",op2);
         //if(eki[1][juego]=op1,op2==1)
         printf ("\t\t %i Y %i EMPATAN\n",op1,op2);  
         }//fin for.
          
    system("PAUSE");
    system("cls");
      }//fin de while.
    return EXIT_SUCCESS;
}//fin de main.
