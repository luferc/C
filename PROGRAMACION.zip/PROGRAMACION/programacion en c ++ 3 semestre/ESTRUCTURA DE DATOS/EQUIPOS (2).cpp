#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;
int total = 0;

int main(int argc, char *argv[])
{
    int equipo[2][16]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16},equipo1[2][16]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16},a=0,b;
    int op, c=0;
    while (op!=17)
    {
     printf("*********** SELECCIONE LOS EQUIPOS **********\n");
     printf("***********          ..VS..        **********\n");
     printf("\t     1.....(CHIVAS)\n");
     printf("\t     2.....(MANCHESTER UNTD).\n");
     printf("\t     3.....(BARCELONA)\n");
     printf("\t     4.....(GALAXI)\n");
     printf("\t     5.....(RIVER)\n");
     printf("\t     6.....(ARSENAL)\n");
     printf("\t     7.....(CHELSEA)\n");
     printf("\t     8.....(LIVERPOOL)\n");
     printf("\t     9.....(AMERICA)\n");
     printf("\t     10....(SAN LUIS)\n");
     printf("\t     11....(MILAN)\n");
     printf("\t     12....(REAL MADRID)\n");
     printf("\t     13....(JUVENTUS)\n");
     printf("\t     14....(DEPORTIVO)\n");
     printf("\t     15....(MANCHESTER CITY)\n");
     printf("\t     16....(PUMAS)\n");             
    printf("\t     (17)..SALIR \n");
    printf("\n\t\t SELECCIONE --> "); 
    scanf("%i",&op);
    system("cls");
    switch(op)
    {
              case 1:
    
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo1 \n");   
              total= total + 3;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo1 \n");
              total= total + 1;
             printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo1 \n"); 
            printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
            printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;
              case 2:
    
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo2 \n");
              total= total + 3;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo2 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo2 \n");
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 3:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo3 \n");
              total= total + 3;  
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo3 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo3 \n");
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 4:
    
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo4 \n"); 
              total= total + 3;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo4 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo4 \n");
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
            printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 5:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo5 \n");
              total= total + 3;  
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo5 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo5 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);
              break;                                                                  
              case 6:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo6 \n");
              total= total + 3;   
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo6 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo6 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 7:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo7 \n");
              total= total + 3;   
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo7 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo7 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 8:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo8 \n");
              total= total + 3;  
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo8 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo8 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 9:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo9 \n"); 
              total= total + 3;  
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo9 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo9 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 10:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo10 \n");
              total= total + 3;   
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            { 
            printf("  equipo10 \n");
            total= total + 1;
            printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
            printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
            printf("  equipo10 \n"); 
            printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
            printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 11:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo11 \n");
              total= total + 3;   
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo11 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo11 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 12:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo12 \n"); 
              total= total + 3; 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo12 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo12 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 13:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo13 \n");
              total= total + 3;   
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo13 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo13 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 14:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo14 \n");
              total= total + 3;  
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo14 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo14 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 15:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo15 \n");
              total= total + 3;   
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo15 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo15 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);  
              break;                                                                  
              case 16:
                       
    printf("\t\t �� TORNEO DE FOOTBALL ��\n");
    printf("\t\t �� 1 gana   = 3 puntos��\n");
    printf("\t\t �� 2 empata = 1 punto ��\n");
    printf("\t\t �� 3 pierde = 0 puntos��\n");
    printf("\t\t ������������������������\n");
    srand(time(0));
    for(int x=0;x<16;x++)
    {
            equipo[1][x]=(rand()%3)+1;
            equipo1[1][x]=(rand()%3)+1;
    }
    printf("\n\n");
    for(int x=0;x<16;x++)
    {
            if(equipo[1][x]<equipo1[1][x])
            {
              printf("  equipo16 \n");  
              total= total + 3; 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 1 gana \n\t 3 puntos\n\n",equipo[1][x],equipo1[1][x]); 
            }     
            if(equipo[1][x]==equipo1[1][x])
            {
              printf("  equipo16 \n");
              total= total + 1;
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 2 empata \n\t 1 punto\n\n",equipo[1][x],equipo1[1][x]);
            }
            if(equipo[1][x]>equipo1[1][x])
            {
              printf("  equipo16 \n"); 
              printf(" partido %d \n",equipo[0][x],equipo1[0][x]);
              printf("        %d    %d = 3 pierde \n\t 0 puntos\n\n",equipo[1][x],equipo1[1][x]);
            }
    }
    printf("\n\n\t TOTAL DE PUNTOS ADQUIRIDOS:%d \n\n",total);   
              break;
              case 17:
                   printf("\n\t\t FIN\n");
                   printf("\n\t\t EQUIPO:\n \n\t\tKAREN IVETEE BARRAGAN MENDEZ \n\n\t\tMARCO ANTONIO  BARRERA RIVERA \n\n\t\tJUAN ALEJANDRO SOLORZANO LOZA \n\n\t");
              break;
              default:
                      printf("\n\t\t ERROR \n\n\t\t");
                              
                                                                                                                                                      

}//fin switch.
    system("PAUSE");
    system("cls");
}//fin de while.
    return EXIT_SUCCESS;
}
