#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    int numero [3][7];
    int x1,x2,x3,v=0;
    /* Datos de Entrada */
    printf ("\t INTRODUZCA LOS VALORES PARA CONVERTILOS: \n");
    for (v=0;v<7;v++){
        scanf ("%i",&x1);
        x1=x1;//valor ingresado.
        x2=x1*x1;//valor al cuadrado.
        x3=x1*x1*x1;//valor al cubo.
        numero[1][v]=x1;
        numero[2][v]=x2;
        numero[3][v]=x3;
        }
    /* Datos de Salida */
    for (v=0;v<7;v++){
        printf ("\t EL VALOR: %i \n",numero[1][v]);
        printf ("\t CUADRADO: %i \n",numero[2][v]);
        printf ("\t CUBO:     %i \n",numero[3][v]);
        }
        printf ("\n NOMBRE: CERVAANTESMARTINEZ LUIS FERNANDO\n");
        printf ("\n CODIGO: 304776313\n");
    system("PAUSE");
    return EXIT_SUCCESS;
}
