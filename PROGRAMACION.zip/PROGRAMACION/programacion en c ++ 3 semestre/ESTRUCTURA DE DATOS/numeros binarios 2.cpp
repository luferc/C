#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int a,x,c=1;
    int bin[3][8]={1,2,4,8,16,32,69,128};
    printf("\t\t��������������������������\n");
    printf("\t\t�    NUMEROS BINARIOS    �\n");
    printf("\t\t��������������������������\n\n\n");
    for(x=0;x<8;x++)
    {
                    
                    printf("DaMe El NuMeRo BiNaRiO \n\n");
                    printf("%d.- ",c);
                    scanf("%d",&a);printf("\n");
               if(a==1||a==0)
               {
               bin[1][x]=a;
               bin[2][x]=a*bin[0][x];
               c++;
               }
               else
               {
               x=x-1;
               printf("\tErroR\n");
               printf("\t\tErroR\n");
               printf("\t\t\t                      �����   �����\n");
               printf("\t\t\tSolo Numeros Binarios � 1 � o � 0 �\n");
               printf("\t\t\t                      �����   �����\n");
               }
               
     }
     
     printf("los numeros1 son %d,%d,%d,%d,%d,%d,%d,%d\n",bin[0][0],bin[0][1],bin[0][2],bin[0][3],bin[0][4],bin[0][5],bin[0][6],bin[0][7],bin[0][8]);
     printf("los numeros2 son %d,%d,%d,%d,%d,%d,%d,%d\n",bin[1][0],bin[1][1],bin[1][2],bin[1][3],bin[1][4],bin[1][5],bin[1][6],bin[1][7],bin[1][8]);
     printf("los numeros3 son %d,%d,%d,%d,%d,%d,%d,%d\n",bin[2][0],bin[2][1],bin[2][2],bin[2][3],bin[2][4],bin[2][5],bin[2][6],bin[2][7],bin[2][8]);
                     
    system("PAUSE");
    return EXIT_SUCCESS;
}

