#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int pos;
  double div [5];
  double multi [5];
  double suma [5];
  double resta [5];
  double var1,var2,var3;
  for (pos=0; pos<=4; pos++) {
      cout<<"\n ingrese el 1er valor:";
      cin>>var1;
      cout<<"\ningrese el 2do valor:";
      cin>>var2;
      cout<<"\n ingrese el 3er valor:";
      cin>>var3;
      div[pos]=(var1/var2/var3);
      multi[pos]=(var1*var2*var3);
      suma[pos]=(var1+var2+var3);
      resta[pos]=(var1-var2-var3);
      }
      for (pos=0;pos<=4;pos++) {
          cout<<"\n arreglo suma:"<<suma[pos]<<"";
          cout<<"\n arreglo resta:"<<resta[pos]<<"";
          cout<<"\n arreglo multiplicacion:"<<multi[pos]<<"";
          cout<<"\n arreglo division:"<<div[pos]<<"";
          }
          
          
    
    system ("PAUSE");
    return 0;
    
}
