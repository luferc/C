#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
      /* Declaracion de Variables */
    int m2 [7];
    int m3 [7];
    int numero;
    int conta;
    
    /* Datos de Entrada */
    for (conta=0;conta<=7;conta++){
        printf ( "ingrese la primera cantidad:\n" );
        scanf ( "%d",&numero );
        m2[conta]=numero*numero;
        m3[conta]=numero*numero*numero;
        }
        /* Datos de Salid */
        for (conta=0;conta<=7;conta++){
            printf ("su numero al cuadrado es= %d\n",m2[conta]);
            printf ("su numero al cubo es= %d\n",m3 [conta]);
            printf ("sus calculos fueron correctos!\n");
            }
        
  
  system("PAUSE");	
  return 0;
}
