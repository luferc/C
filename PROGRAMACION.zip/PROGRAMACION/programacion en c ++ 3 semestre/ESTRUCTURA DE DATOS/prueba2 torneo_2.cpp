#include <cstdlib>
#include <iostream>
#include <time.h>

using namespace std;

int main(int argc, char *argv[])
{
    int eki[2][8];
    int juego,resul,op1,op2;
    int opcion=1;
    while ( opcion !=9 )
    {
    printf("\t\t��������������������������\n");
    printf("\t\t�                        �\n");
    printf("\t\t�   CUP INTER-CLUB 2009  �\n");
    printf("\t\t�                        �\n");
    printf("\t\t��������������������������\n\n\n");
         
              printf("*********** SELECCIONE LOS EQUIPOS **********\n");
              printf("***********          ..VS..        **********\n");
              printf("\t     (1).....CHIVAS\n");
              printf("\t     (2).....MANCHESTER UNTD.\n");
              printf("\t     (3).....BARCELONA\n");
              printf("\t     (4).....GALAXI\n");
              printf("\t     (5).....RIVER\n");
              printf("\t     (6).....ARSENAL\n");
              printf("\t     (7).....CHELSEA\n");
              printf("\t     (8).....LIVERPOOL\n");
              printf("\t     (9).....SALIR\n");
              scanf("%i""%i",&op1,&op2);
                if (op1==9 && op2==9) break; // Solo para salir del ciclo, cuando se elije el 9
              system("cls");
              srand(time(NULL));

          printf("\t\t   ��������������������������\n");
          printf("\t\t   �                        �\n");
          printf("\t\t   �  [1] GANA   = 3 PTS.   �\n");
          printf("\t\t   �  [2] EMPATA = 1 PTS.   �\n");
          printf("\t\t   �  [3] PIERDE = 0 PTS.   �\n");
          printf("\t\t   �                        �\n");
          printf("\t\t   ��������������������������\n");
          printf("\n\n\t\t %i VS %i ",op1,op2);
      
         for  (juego=0;juego<=6;juego++)
          {    
                    // numero aleatorio del 1 a 3.
             resul = 1 + rand() % 3;
                     // Asignar datos.
              eki[0][juego]=resul;
         }//fin for. 
         
         for  (juego=0;juego<=6;juego++)
         {
                                   // Comparar datos
                         if (eki[0][juego]==3) {eki[1][juego]=0;  printf("\n\t\t Resultado :%i, Puntos:0 Pierde\n",eki[0][juego]);break;}
                         if (eki[0][juego]==2) {eki[1][juego]=1;  printf("\n\t\t Resultado :%i, Puntos:1 Empatado\n",eki[0][juego]);break;}
                         if (eki[0][juego]==1) {eki[1][juego]=3;  printf("\n\t\t Resultado :%i, Puntos:3 Gana\n",eki[0][juego]);break;}    
        }//fin for.             
         printf("\n\n Para continuar ...\n");
    system("PAUSE");
    system("cls");
      }//fin de while.
    return EXIT_SUCCESS;
}//fin de main.
