#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <time.h>
#define TAMANIO 9

using namespace std;

int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    int eki[TAMANIO]={0};  // arreglo de equipos.
    int juegos;    //  contador de partidos  jugados.
    int resultado;//   resultados de los partidos.
    /* Datos de Entrada */
    srand (time(NULL)); // generador de semilla de los numeros aleatorios.
    for ( juegos = 1; juegos <= 9; juegos++ )// ciclo de 8 juegos. 
    {
        resultado = 1 + rand() %3; // numeros aleatorios de 1 a 3.
        ++ eki[resultado];
        }// fin de for.
        printf ("%s%17s\n", "PARTIDOS", "PUNTOS");
        /* muestra la puntuacion en forma tabular */
        for (resultado = 1; resultado < TAMANIO; resultado++)
        {
            printf ("%4d%18d\n",resultado,eki[resultado]);
            }//fin de for.
    system("PAUSE");
    return EXIT_SUCCESS;
}
