#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int contador, dias, total, personas;
  total=0;
  contador=1;
  while (contador <=12) {
        printf ("dias: \n");
        scanf ("%d",&dias);
        total=total + dias;
        contador=contador+1;
        }
        personas=total;
        printf ("total de personas en 5 dias: %d\n",personas);  
  system("PAUSE");	
  return 0;
}
