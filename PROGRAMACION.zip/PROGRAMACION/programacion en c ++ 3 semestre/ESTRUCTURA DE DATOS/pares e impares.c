#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{                  
int x,n,p=0,par=0,non=0,no=0;
int pares [ 9 ];
int nones [ 9 ];

for (n=0;n<=9;n++){
    scanf ( "%d",&x );
    if ( x%2==0 ){
         pares [ p ]=x;
         par++;
         p++;
         }
         else{
         nones [ no ]=x;
         non++;
         no++;}
         }
         for (p=0;p<par;p++){
             printf ("los pares: %d\n", pares [ p ]);
             }
             for (no=0;no<non;no++){
                 printf("los nones: %d\n",nones [ no ]);
                 }
 system("PAUSE");	
  return 0;
}
