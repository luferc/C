#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  
int contador;
int i;
int almacena;

int x,n,p=0,par=0,non=0,no=0;
int pares [ 6 ];
int nones [ 6 ];

for (n=0;n<=6;n++){
    scanf ( "%d",&x );
    if ( x%2==0 ){
         pares [ p ]=x;
         par++;
         p++;
         }
         else{
         nones [ no ]=x;
         non++;
         no++;}
         }
         for (p=0;p<par;p++){
             printf ("los pares: %d\n", pares [ p ]);
             }
             for (no=0;no<non;no++){
                 printf("los nones: %d\n",nones [ no ]);
                 }
for (contador=1;contador<=6;contador++){
        if (pares[p]>pares[p+1]){
                         almacena=pares[p];
                         pares[p]=pares[p+1];
                         pares[p+1]=almacena;
                         }
                         
                         for (p=0;p>par;p++){
                         printf ("pares de mayor a menor: %d",pares[p]);
                         }
                         printf ("\n el numero par menor es: %d\n\n",pares[p]);
                         
    if (nones[no]>nones[no+1]){
                              almacena=nones[no];
                              nones[no]=nones[no+1];
                              nones[no+1];
                              nones[no+1]=almacena;
                              }
                              
                              for (no=0;no>non;no++){
                                  printf ("\n el numero impar es: %d\n\n",nones[no]);
                                  }
                                  printf ("\n el numero impar menor es: %d\n\n",nones[no]);
                                  
                              

                         


  system("PAUSE");	
  return 0;
}
}

