#include <cstdlib>
#include <iostream>
#include <stdlib.h>
#include <time.h>

using namespace std;


int main(int argc, char *argv[])
{
    int eki[2][8];
    int juego,resul,marcador1,marcador2;
    printf ("\t TORNEO RELAMPAGO\n\n");
    printf ("\n  GANA   = 3 PTS.\n");
    printf ("\n  EMPATA = 1 PTS.\n");
    printf ("\n  PIERDE = 0 PTS.\n");
    srand(time(0));
    for (juego=1;juego<=8;juego++)
    {
        /* JUGARAN */
        switch (juego){
              case 1: //partido 1.
              printf ("\n\t PRIMER PARTIDO\n");
              marcador1 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
              marcador2 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
              printf ("\n\n\t AMERICA %i VS CHIVAS %i \n",marcador1,marcador2);
              resul = 1 + rand() % 3; // numero aleatorio del 1 a 3.
              /*eki[0][juego]=resul;
              if (eki[0][juego] ==3)
              eki[1][juego]=0;
              if (eki[0][juego]==2)
              eki[1][juego]=1;
              if (eki[0][juego]==1)
              eki[1][juego]=3; 
              printf ("\n\t\t %i\n\t\t %i PUNTOS.\n",eki[0][juego],eki[1][juego]);*/
                                   if((marcador1 > marcador2==resul)||((marcador2 > marcador1== resul))
                                   printf("\n\t\t %i GANA\n",resul);
                                   if((marcador2 < marcador1==resul)||((marcador1 < marcador2==resul))
                                   printf("\n\t\t %i PIERDE\n",resul);
                                   else if (marcador1==marcador2)
                                   printf("\n\t\t  EMPATE\n");
             
                                 break;
                                 case 2: //partido 2.
                                 printf ("\n\t SEGUNDO PARTIDO \n");
                                 marcador1 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
                                 marcador2 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
                                 printf ("\n\n\t SANTOS %i VS TOLUCA %i \n",marcador1,marcador2);
                                   resul = 1 + rand() % 3; // numero aleatorio del 1 a 3.
                                   /*eki[0][juego]=resul;
                                   if (eki[0][juego] ==3)
                                   eki[1][juego]=0;
                                   if (eki[0][juego]==2)
                                   eki[1][juego]=1;
                                   if (eki[0][juego]==1)
                                   eki[1][juego]=3;
                                   printf ("\n\t\t %i\n\t\t %i PUNTOS.\n",eki[0][juego],eki[1][juego]);*/
                                   if (marcador1>marcador2)
                                   printf("\n\t\t %i GANA\n");
                                   if (marcador1<marcador2)
                                   printf("\n\t\t %i PIERDE\n");
                                   else if (marcador1==marcador2)
                                   printf("\n\t\t  EMPATE\n");
                                             break;
                                             case 3: //partido 3.
                                             printf ("\n\t TERCER PARTIDO \n");
                                             marcador1 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
                                             marcador2 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
                                             printf ("\n\n\t CRUZ AZUL %i VS PACHUCA %i \n",marcador1,marcador2);
                                               resul = 1 + rand() % 3; // numero aleatorio del 1 a 3.
                                               /*eki[0][juego]=resul;
                                               if (eki[0][juego] ==3)
                                               eki[1][juego]=0;
                                               if (eki[0][juego]==2)
                                               eki[1][juego]=1;
                                               if (eki[0][juego]==1)
                                               eki[1][juego]=3;
                                               printf ("\n\t\t %i\n\t\t %i PUNTOS.\n",eki[0][juego],eki[1][juego]);*/
                                               if (marcador1>marcador2)
                                               printf("\n\t\t %i GANA\n");
                                               if (marcador1<marcador2)
                                               printf("\n\t\t %i PIERDE\n");
                                               else if (marcador1==marcador2)
                                               printf("\n\t\t EMPATE\n");
                                                                break;
                                                                case 4: //partido 4.
                                                                printf ("\n\t CUARTO PARTIDO \n");
                                                                marcador1 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
                                                                marcador2 = 0 + rand() % 5;// numeros aleatorios del 0 a 5.
                                                                printf ("\n\n\t ATLAS %i VS INDIOS %i \n",marcador1,marcador2);
                                                                resul = 1 + rand() % 3; // numero aleatorio del 1 a 3.
                                                                /*eki[0][juego]=resul;
                                                                if (eki[0][juego] ==3)
                                                                eki[1][juego]=0;
                                                                if (eki[0][juego]==2)
                                                                eki[1][juego]=1;
                                                                if (eki[0][juego]==1)
                                                                eki[1][juego]=3;
                                                                printf ("\n\t\t %i\n\t\t %i PUNTOS.\n",eki[0][juego],eki[1][juego]);*/
                                                                if (marcador1>marcador2)
                                                                printf("\n\t\t %i GANA\n");
                                                                if (marcador1<marcador2)
                                                                printf("\n\t\t %i PIERDE\n");
                                                                else if (marcador1==marcador2)
                                                                printf("\n\t\t  EMPATE\n");
                                                                break;
                                                                                  }// fin de switch.
                                                                                  }// fin de for.
                               
    system("PAUSE");
    return EXIT_SUCCESS;
}

