#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    /* Declaracion de Variables */
    int promedio[1][7];// Arreglo Bidimensional 
    int n1,n2,a=0,b=0,c1,c2,x;
    /* Datos de Entrada */
    printf ("\n INTRODUZCA LOS NUMEROS:\n");
    for (x=0;x<7;x++)
    {
        scanf ("%i",&n1);
        n1=n1;
        n2=n1+n1;
        a=a+n1;
        b=b+n2;
        promedio[1][x]=n1;
        promedio[2][x]=n2;
    }
    /* Datos de Salida */
    c1=a/7;
    c2=b/7;
    for (x=0;x<7;x++)
    {
        printf ("\n\t NUMERO:  %i",promedio[1][x]);
        printf ("\n\t DOBLE:   %i",promedio[2][x]);
        }
        printf ("\n\t LOS PROMEDIOS SON: %i%i\n",c1,c2);
    system("PAUSE");
    return EXIT_SUCCESS;
}
