#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
int materias[8];
int calif,a,prom=0;

for(a=1;a<=8;a++)
{
    printf("dame la calificacion\n");
    scanf("%d",&calif);
    prom+=calif;
    materias[a]=calif;
}   

 
 for(int a=1;a<=8;a++)
 {
    printf("Calificacion %d es %d\n",a,materias[a]);
 }
prom=prom/8;
printf("el promedio es %d \n",prom);

    system("PAUSE");
    return EXIT_SUCCESS;
}
