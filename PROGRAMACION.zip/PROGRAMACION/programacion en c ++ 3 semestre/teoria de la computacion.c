#include <stdio.h>
#include <stdlib.h>

int main()
{
  int sum,rest,mult,div,a,b;
  printf ( "introduce dos numeros: \n" );
  scanf ("%d%d",&a,&b );
  sum=a+b;rest=a-b;mult=a*b;div=a/b;
  printf ( "la suma es:%d,resta:%d,multiplicacion:%d,division:%d\n",sum,rest,mult,div );
  system("PAUSE");	
  return 0;
}
