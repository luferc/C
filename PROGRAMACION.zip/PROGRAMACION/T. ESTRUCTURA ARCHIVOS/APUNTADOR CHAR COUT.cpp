/*
MATERIA: TALLAER DE ESTRUCTURA DE ARCHIVOS.
MAESTRO: JOYA LOMELI.
NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO.
CODIGO: 304776313
CARRERA: ING. COMPUTACION
PROGRAMA: APUNTADORES QUINTA PARTE.
CARACTERISTICA: APUNTADOR CON CARACTER  CHAR. Y COUT(SON MUY PODEROSOS)
FECHA: 30/OCTUBRE/2009 
*/
#include <cstdlib>
#include <iostream>
#include <string.h>
using namespace std;

int main(int argc, char *argv[])
{
      // DECLARACION VARIABLES
    char *apuntador; //apuntador *.
    char nom[10];
    char nom2[10];
    char ape[10];
    char ape2[10];
    int i,tam;
    
    //CICLOS:
    printf("\n\n\t PRIMER NOMBRE    --> ");
    scanf("%s",&nom);
    tam=strlen(nom);
    printf("\n\n\t EL DATO PESA %i",tam);
  
    for(i=0;i<=tam;i++)
    {  
     apuntador=&nom[i];
    printf("\n\n\t CARACTER [%i]--> %s",i,apuntador);
    printf("\n\n\t DIRECCION MEMORIA --> %i ",apuntador);
    system("pause");
    }//fin for.
    
 
    printf("\n\n\t SEGUNDO NOMBRE    --> ");
    scanf("%s",&nom2);
    tam=strlen(nom2);
    printf("\n\n\t EL DATO PESA %i",tam);
    for(i=0;i<=tam;i++)
    {
    apuntador=&nom2[i];
    printf("\n\n\t CARACTER [%i]--> %s",i,apuntador);
    printf("\n\n\t DIRECCION MEMORIA --> %i ",apuntador);
    system("pause");
    }//fin for.
    
    printf("\n\n\t PRIMER APELLIDO  --> ");
    scanf("%s",&ape);
    tam=strlen(ape);
    printf("\n\n\t EL DATO PESA %i",tam);
    for(i=0;i<=tam;i++)
    {
    apuntador=&ape[i];
    printf("\n\n\t CARACTER [%i]--> %s",i,apuntador);
    printf("\n\n\t DIRECCION MEMORIA --> %i ",apuntador);
    system("pause");
    }
    
    printf("\n\n\t SEGUNDO APELLIDO  --> ");
    scanf("%s",&ape2);
    tam=strlen(ape2);
    printf("\n\n\t EL DATO PESA %i",tam);
    for(i=0;i<=tam;i++)
    {
    apuntador=&ape2[i];
    printf("\n\n\t CARACTER [%i]--> %s",i,apuntador);
    printf("\n\n\t DIRECCION MEMORIA --> %i ",apuntador);
    system("pause");
    
    }
    /*apuntador=&nom2[0];
    cout<<"NOMBRE"<<nom2;
    cout<<"DIRECCION MEMORIA = "<<int(apuntador);*/
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
