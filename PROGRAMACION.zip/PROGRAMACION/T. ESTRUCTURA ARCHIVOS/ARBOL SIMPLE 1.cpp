/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: FUNCIONAMIENTO DE UN ARBOL BINARIO          $
$          LISTA,PILA,COLA,ARBOL,ARBOL BINARIO Y MENU  $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/   
#include <cstdlib>
#include <iostream>

using namespace std;
//   FUNCIONES
int llenado();
int llenadopila();
int llenadocola();
int lista[10];
int pila[5];
int cola[8];
int arbol[50];
int main(int argc, char *argv[])
{
// VARIABLES LOCALES
int op,cont=0,cont1=0,num;
//........................................................................................................................
    do
    {
    //MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   987654321012345678909876543210123456\n");
    printf("\t   123456789098765432101234567890987654\n");
    printf("\t   2               MENU               3\n");
    printf("\t   3                                  2\n");
    printf("\t   4  (1)--> LLENAR LISTA             1\n");
    printf("\t   5  (2)--> LLENAR PILA O COLA       0\n");
    printf("\t   6  (3)--> LLENAR ARBOL             1\n");
    printf("\t   7  (4)--> CONSULTAR DATOS EN ARBOL 2\n");
    printf("\t   7  (5)--> DETERMINAR TIPO DE ARBOL 2\n");
    printf("\t   8  (6)--> SALIR                    3\n");
    printf("\t   9                                  4\n");
    printf("\t   987654321012345678909876543210123456\n");
    printf("\t   123456789098765432101234567890987654\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op);
    system("cls");
//........................................................................................................................
    switch(op)
    {
    case 1://lista
    do
    {
    //SUB--MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   ------------------------------------\n");
    printf("\t   -           SUB-MENU               -\n");
    printf("\t   -                                  -\n");
    printf("\t   -   (1)--> LLENAR LISTA            -\n");
    printf("\t   -   (2)--> CONSULTAR               -\n");
    printf("\t   -   (3)--> SALIR                   -\n");
    printf("\t   ------------------------------------\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op);
    system("cls");
    switch(op)
    {
    case 1://llenar lista.
    printf("\n\t LISTA \n");
    llenado();
    break;
    case 2:// CONSULTAR LISTA EN SUB-MENU.
    printf("\n\n\t\t LISTA \n");
    for(int x=0; x<=5; x++)
    {
    printf("\t\t ���������\n");
    printf("\t\t �       �\n");
    printf("\t\t �   %i   �\n", lista[x]);
    printf("\t\t �       �\n");
    printf("\t\t ���������\n");
    if(lista[x]<0)
    {
    printf("\n\n");
    printf("\t\t ����� \n");
    printf("\t\t �   � \n");
    printf("\t\t ����� \n");
    printf("\t\t �   � \n");
    printf("\t\t ����� \n");
    printf("\t\t �   � \n");
    printf("\t\t ����� \n");
    printf("\t\t �   � \n");
    printf("\t\t ����� \n");
    }
    }//fin for.
    system("PAUSE");
    default:
    printf("error");
    }//fin switch
    }while(op!=3);
    break;
//........................................................................................................................
    case 2:
    do
    {
        //SUB--MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   ------------------------------------\n");
    printf("\t   -           SUB-MENU               -\n");
    printf("\t   -                                  -\n");
    printf("\t   -   (1)--> LLENAR PILA             -\n");
    printf("\t   -   (2)--> LLENAR COLA             -\n");
    printf("\t   -   (3)--> SALIR                   -\n");
    printf("\t   ------------------------------------\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op);
    system("cls");
    switch (op)
    {
    case 1:
    printf("\n\n\t PILA \n");
    llenadopila();              
    for(int x=5; x>=0; x--)
    {
    printf("\t\t ���������\n");
    printf("\t\t �       �\n");
    printf("\t\t �   %i   �\n", pila[x]);
    printf("\t\t �       �\n");
    printf("\t\t ���������\n");
    }//fin for.
    system("PAUSE");
    break;
                            
    case 2:
    printf("\n\n\t COLA \n");
    llenadocola();                               
    for(int x=0; x<=5; x++)
    {
    printf("\t\t ���������\n");
    printf("\t\t �       �\n");
    printf("\t\t �   %i   �\n", cola[x]);
    printf("\t\t �       �\n");
    printf("\t\t ���������\n");
    }//fin for
    system("PAUSE");
    break;
    }//fin switch
    }while(op!=3);//fin del ciclo do-->while
    break;          
//........................................................................................................................
    case 3:
    do
    {
            //SUB--MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   ------------------------------------\n");
    printf("\t   -           SUB-MENU               -\n");
    printf("\t   -                                  -\n");
    printf("\t   -   (1)--> PILA --> ARBOL          -\n");
    printf("\t   -   (2)--> COLA --> ARBOL          -\n");
    printf("\t   -   (3)--> SALIR                   -\n");
    printf("\t   ------------------------------------\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op);
    system("cls");    
    switch (op)
    {
    case 1: 
    printf("\n\n\t DATOS INGRESADOS: \n ");
    for(int x=5; x>=0; x--)
    {
    printf("\t\t ���������\n");
    printf("\t\t �       �\n");
    printf("\t\t �   %i   �\n", pila[x]);
    printf("\t\t �       �\n");
    printf("\t\t ���������\n");
    arbol[cont]=pila[x];
    cont++;      
    }//fin for
    printf("\n\t LISTO..! \n");
    system("PAUSE");
    break;
    case 2: 
    printf("\n\n\t DATOS INGRESADOS: \n ");
    for(int x=0; x<=5; x++)
    {
    printf("\t\t ���������\n");
    printf("\t\t �       �\n");
    printf("\t\t �   %i   �\n", cola[x]);
    printf("\t\t �       �\n");
    printf("\t\t ���������\n");
    arbol[cont]=cola[x];
    cont++;
    }//fin for
    printf("\n\t LISTO..! \n");
    system("PAUSE");
    break;
    }//fin switch
    }while(op!=3); //fin ciclo do--> whilr
    break;                     
//........................................................................................................................
    case 4:
    printf("\n\n\t ARBOL \n");
    for(int x=0; x<cont; x++)
    {
    printf("\t\t ���������\n");
    printf("\t\t �       �\n");
    printf("\t\t �   %i   �\n", arbol[x]);
    printf("\t\t �       �\n");
    printf("\t\t ���������\n");
    }//fin for
    system("PAUSE");
    break;             
//........................................................................................................................
    case 5:
    for(int x=0;x<cont; x++)
    {
    if(0==arbol[x])
    cont1++;
    }//fin for
    num=(cont1 % 2);
    if(num==0)
    printf("\n\t ARBOL BINARIO \n\n\n");
    else
    printf("\n\t ARBOL SIMPLE \n\n\n");
    system("PAUSE");
    break; 
//........................................................................................................................
    default:
    printf("\n");
    printf("\t\t        ......................  \n");
    printf("\t\t       ..  x        x       ..  \n");                    
    printf("\t\t      . .    x    x        . .  \n");
    printf("\t\t     .  .      x          .x .  \n");
    printf("\t\t    .   .    x   x       . x .  \n");
    printf("\t\t   .    .  x       x    .  x .  \n");
    printf("\t\t   ..................... x x .  \n");
    printf("\t\t   .    .x       x     . x x .  \n");
    printf("\t\t   .    .  x   x       . x x .  \n");
    printf("\t\t   .   .     x         . x x.   \n");
    printf("\t\t   .  .    x   x       . x .    \n");
    printf("\t\t   . .   x       x     . x.     \n");
    printf("\t\t   ..                  . .     \n");
    printf("\t\t   .....................       \n");
    }//fin switch
    }while(op!=6);//CICLO
    return EXIT_SUCCESS;
}
//  LAMADO DE FUNCIONES
//........................................................................................................................
int llenado()
{
int num;
for(int x=0; x<=5; x++)
{
if(x == 5)
lista[x]=NULL;
else
{
printf("\n\t [%i]DATO --> ",x);
scanf("%i",&num);
lista[x]=num;
pila[x]=lista[x];
cola[x]=lista[x];      
}//fin else.                                                        
if (x>=5)
{
printf("\n\n\n");
printf("\t    �������������������\n");
printf("\t    �  LISTA AL LIMITE�\n");
printf("\t    �        :(       �\n");
printf("\t    �������������������\n"); 
system("pause");                                        
system("cls");
}//fin if
else
{
printf("\n\n\n");
printf("\t    ��������������������\n");                                       
printf("\t    �DATO INGRESADO .  �\n");
printf("\t    �              .   �\n");
printf("\t    �             .    �\n");
printf("\t    �            .     �\n");
printf("\t    �       .   .      �\n");
printf("\t    �         ..       �\n");
printf("\t    ��������������������\n");
system("cls");
}//fin else
}//fin for.
}//fin fun. llenado.
//........................................................................................................................
int llenadopila()
{
for(int x=0; x<=5;x++)
{
if(x == 5)
pila[x]=NULL;
else
pila[x]=lista[x];
}
}
//........................................................................................................................
int llenadocola()
{
for(int x=0; x<=5;x++)
{
if(x == 5)
cola[x]=NULL;
else
cola[x]=lista[x];
}
}
//........................................................................................................................
