/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: FUNCIONAMIENTO DE UN ARBOL BINARIO          $
$          LISTA,PILA,COLA,ARBOL,ARBOL BINARIO Y MENU  $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/   

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#define  MAX   5
//........................................................................................................................
using namespace std;
//                    FUNCIONES GLOBALES
bool ingre(int dato1);
bool imprimir   ( );
bool listaVacia ( );
bool listaLlena ( );
int lista[MAX];
int arbol[20]={0};
int tope=-1;
//........................................................................................................................
int main(int argc, char *argv[])
{
    //             VARIABLES LOCALES
    //variables
    int i=0,op,op2,op3;
    //ARREGLOS
    int l[5]={0};//l=lista declarada desde 0
    int p[5]={0};//p=pila declarada desde 0
    int c[5]={0};//c=cola declarada desde 0
    int x[5]={0};
    int a1[5]={0};
    int a2[5]={0};
    int cont=0;
    int num[5]={0};
//........................................................................................................................
    while(op!=5)//CICLO
    {
    //MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   987654321012345678909876543210123456\n");
    printf("\t   123456789098765432101234567890987654\n");
    printf("\t   2               MENU               3\n");
    printf("\t   3                                  2\n");
    printf("\t   4  (1)--> LLENAR LISTA             1\n");
    printf("\t   5  (2)--> CONSULTAR DATOS EN PILA  0\n");
    printf("\t   6  (3)--> CONSULTAR DATOS EN COLA  1\n");
    printf("\t   7  (4)--> CONSULTAR DATOS EN ARBOL 2\n");
    printf("\t   8  (5)--> SALIR                    3\n");
    printf("\t   9                                  4\n");
    printf("\t   987654321012345678909876543210123456\n");
    printf("\t   123456789098765432101234567890987654\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op);
    system("cls");
    switch(op)
    {
//........................................................................................................................    
    case 1://lista
    while(op2!=3)
    {
    //SUB--MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   ------------------------------------\n");
    printf("\t   -           SUB-MENU               -\n");
    printf("\t   -                                  -\n");
    printf("\t   -   (1)--> LLENAR LISTA            -\n");
    printf("\t   -   (2)--> CONSULTAR               -\n");
    printf("\t   -   (3)--> SALIR                   -\n");
    printf("\t   ------------------------------------\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op2);
    system("cls");
    switch(op2)
    {
    case 1://llenar lista.
    printf("\n\t LISTA \n");
    for(int i=0;i<=4;i++)
    {
    if(i == 5)
    l[i]=NULL;
    else
    {
    printf("\n\t [%i]DATO --> ",i);
    scanf("%i",&l[i]);    
    }
   /* p [i] =num[i];
    c [i] =num[i];
    x [i] =num[i];*/
    if(!ingre(l[i]))
    {
     printf("\n\n\n");
     printf("\t    �������������������\n");
     printf("\t    �  LISTA AL LIMITE�\n");
     printf("\t    �        :(       �\n");
     printf("\t    �������������������\n");                                         
     system("cls");
    }//fin if
    else
    {
    printf("\n\n\n");
    printf("\t    ��������������������\n");                                       
    printf("\t    �DATO INGRESADO .  �\n");
    printf("\t    �              .   �\n");
    printf("\t    �             .    �\n");
    printf("\t    �            .     �\n");
    printf("\t    �       .   .      �\n");
    printf("\t    �         ..       �\n");
    printf("\t    ��������������������\n");
    system("cls");
    }//fin else
    }// fin de for.
    break;//TERMINA EL CASE 1 DEL SUB MENU.
//..............................................................................
    case 2:// CONSULTAR LISTA EN SUB-MENU.
    printf("\n\n\t CONSULTA DE DATOS \n\n");
    if (!imprimir() )
    {
    printf("\n\t LISTA VACIA \n");
    }
    printf("\n\n"); 
    system("pause");                                             
    break;
//..............................................................................
    case 3://salir
    printf("\n\n\t AL MENU PRINCIPAL...!!!");
    break;
    
    default:
    printf("\n");
    printf("\n\t E");
    printf("\n\t  R");
    printf("\n\t   R");
    printf("\n\t    O");
    printf("\n\t     R");
    printf("\n");
    }// fin switch sub menu
    }// fin while. sub menu.
    break;
//........................................................................................................................    
    case 2:
    if (!imprimir() )
    {
    printf("\n\t LISTA VACIA \n");
    }
    printf("\n\t\t CONSULTA DE DATOS EN LA PILA \n\n\n");
    for (i=4;i>=0;i--)
    {
    if (i==4)
    p[i]=NULL;
    else
    p[i]=l[i];
    {
    printf("\t  |POSICION |   DATO  | CARACTERISTICA         \n");
    printf("\t  ------------------------------------------ \n");
    printf("\t  |  [%i]   |    %i     ULTIMO DATO EN ENTRAR  \n",i+1,p[i]);
    }//fin if
    else
    {
    printf("\t  ------------------------------------------ \n");
    printf("\t  |  [%i]   |    %i     EL DATO SIGUIENTE      \n",i+1,p[i]);
    printf("\t  ------------------------------------------ \n");
    }//fin else
    }//fin de for.
    system("pause");                                             
   
    break;
//........................................................................................................................
    case 3:
    if (!imprimir() )
    {
    printf("\n\t LISTA VACIA \n");
    }
    printf("\n\n"); 
    printf("\n\t\t CONSULTA DE DATOS EN LA COLA \n\n\n");
    for (i=0;i<=4;i++)
    {
    if (i==0)
    c[i]=NULL;
    else
    c[i]=l[i];
    {
    printf("\t  |POSICION |   DATO  | CARACTERISTICA         \n");
    printf("\t  ------------------------------------------ \n");
    printf("\t  |  [%i]   |    %i     PRIMER DATO EN ENTRAR  \n",i+1,c[i]);
    }//fin if
    else
    {
    printf("\t  ------------------------------------------ \n");
    printf("\t  |  [%i]   |    %i     EL DATO SIGUIENTE      \n",i+1,c[i]);
    printf("\t  ------------------------------------------ \n");
    }//fin else    
    }//fin for
    system("PAUSE");

    break;
//........................................................................................................................
    case 4:
    while(op3!=3)//CICLO    
    {
        //SUB--MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   ------------------------------------\n");
    printf("\t   -           SUB-MENU               -\n");
    printf("\t   -                                  -\n");
    printf("\t   -   (1)--> LLENAR ARBOL            -\n");
    printf("\t   -   (2)--> CONSULTAR               -\n");
    printf("\t   -   (3)--> SALIR                   -\n");
    printf("\t   ------------------------------------\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op3);
    system("cls");
    switch(op3)
    {
    case 1://llenar arbol
    do{
    system("cls");
    printf("\n\n\n");
    printf("\t   ------------------------------------\n");
    printf("\t   -           SUB-MENU               -\n");
    printf("\t   -                                  -\n");
    printf("\t   -   (1)--> LLENAR CON PILA         -\n");
    printf("\t   -   (2)--> LLENAR CON COLA         -\n");
    printf("\t   -   (3)--> SALIR                   -\n");
    printf("\t   ------------------------------------\n");
    printf("\n SELECCIONE �-->  ");
    scanf("%i",&op);
    switch (op)
    {
    case 1: 
    for(int x=4; x>=0; x--)
    {
    printf("\n\t DATO OBTENIDO --> (%i) ",p[x]);
    arbol[cont]=p[x];
    cont++;      
    }
    printf("\n\t LA PILA A LLENADO EL ARBOL \n");
    system("PAUSE");
    break;
    case 2: 
    for(int x=0; x<=4; x++)
    {
    printf("\n\t DATO OBTENIDO --> (%i) ",c[x]);
    arbol[cont]=c[x];
    cont++;
    }
    printf("\n\t LA COLA A LLENADO EL ARBOL\n");
    system("PAUSE");
    break;
    }
    }while(op!=3); 
    break;
                               
    /*
    if (!imprimir() )
    {
    printf("\n\t LISTA VACIA \n");
    }
   pila() ;
   cola();*/
//..............................................................................
    case 2://consultar
    printf("\n\t******* EL PUTO ARBOL *******\n\n");
    for(int x=0; x<cont; x++)
    {
    printf("\n\t VALOR --> (%i) ",arbol[x]);
    }
    system("PAUSE");           
    break;
//..............................................................................
    case 3://salir
    break;
//..............................................................................
    default:
    printf("ERROR");
    }//fin switch
    }//fin while.
    break;
//........................................................................................................................
    case 5:
    break;
//........................................................................................................................
    default:
    printf("\n");
    printf("\t\t        ......................  \n");
    printf("\t\t       ..  x        x       ..  \n");                    
    printf("\t\t      . .    x    x        . .  \n");
    printf("\t\t     .  .      x          .x .  \n");
    printf("\t\t    .   .    x   x       . x .  \n");
    printf("\t\t   .    .  x       x    .  x .  \n");
    printf("\t\t   ..................... x x .  \n");
    printf("\t\t   .    .x       x     . x x .  \n");
    printf("\t\t   .    .  x   x       . x x .  \n");
    printf("\t\t   .   .     x         . x x.   \n");
    printf("\t\t   .  .    x   x       . x .    \n");
    printf("\t\t   . .   x       x     . x.     \n");
    printf("\t\t   ..                  . .     \n");
    printf("\t\t   .....................       \n");

}//fin switch
    system("cls");
}//fin while
    return EXIT_SUCCESS;
}//fin main.
//                                      LLAMADO DE FUNCIONES
//........................................................................................................................
bool ingre(int dato2)//Funcion Ingresar.
{
if ( !listaLlena () )
{
tope += 1;
lista[tope] = dato2;
return true;
}
else
return false;
}
//........................................................................................................................
bool imprimir ( )//Funcion Imprimir.
{
int c;
if ( !listaVacia () )
{
printf("\n\n\t IMAGEN DE LA LISTA:\n\n" );
for ( c = lista[MAX]; c <=  MAX; c++ )
{
printf("\t\t ���������\n");
printf("\t\t �       �\n");
printf("\t\t �   %i   �\n", lista[c]);
printf("\t\t �       �\n");
printf("\t\t ���������\n");
}//Fin de For.
return true;
}//Fin de if.
else{
printf("\n\n");
printf("\t\t ����� \n");
printf("\t\t �   � \n");
printf("\t\t ����� \n");
printf("\t\t �   � \n");
printf("\t\t ����� \n");
printf("\t\t �   � \n");
printf("\t\t ����� \n");
printf("\t\t �   � \n");
printf("\t\t ����� \n");
return false;
}//Fin de Else.
}//fin funcion imprimir.
//........................................................................................................................
bool listaVacia ( )//Funcion Pila Vacia.
{
if ( tope  == -1 )
return true;
else
return false;
}
//........................................................................................................................
bool listaLlena ( )//Funcion Pila Max.
{
if ( tope + 1 == MAX )
return true;
else
return false;
}
//........................................................................................................................ 
