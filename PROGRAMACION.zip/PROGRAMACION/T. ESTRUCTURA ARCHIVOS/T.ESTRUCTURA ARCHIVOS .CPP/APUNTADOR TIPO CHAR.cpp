/*
MATERIA: TALLAER DE ESTRUCTURA DE ARCHIVOS.
MAESTRO: JOYA LOMELI.
NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO.
CODIGO: 304776313
CARRERA: ING. COMPUTACION
PROGRAMA: APUNTADORES SEGUNDA PARTE.
CARACTERISTICA: APUNTADOR CON CARACTER  CHAR.(SON MUY PODEROSOS)
FECHA: 27/OCTUBRE/2009 
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
      // DECLARACION VARIABLES
    char *apuntador; //apuntador *.
    char nom[15];
    
    //uso del apuntador:
  //  apuntador=&nom[0];// ASIGNAR LA PRIMERA VARIABLE "OBLIGATORIO"
    printf("\n\n\t NOMBRE -->  ");
    scanf("%s",&nom);
    for(int k=0;k<=20;k++)
    {
    apuntador=&nom[k];
    printf("\n\n\t TU NOMBRE [%i]--> %s",k,apuntador);
    printf("\n\n\t DIRECCION MEMORIA --> %i",apuntador);//imprime direccion de mamoria de la variable.
    printf("\n\n");
    system("PAUSE");
    }//fin for
    
    return EXIT_SUCCESS;
}
