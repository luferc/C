#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int edad;
    int *apunta;
    edad=25;
    apunta=&edad;
    printf("\n\t APUNTADORES \n");
    printf("\n VALOR DE LA VARIABLE \n\n EDAD --> %i ",edad);
    printf("\n SU DIRECCION DE MEMORIA = %i ",apunta);
    printf("\n\n\n");
    cout<<"\n SU DIRECCION EN BAJO NIVEL ES -->  "<<apunta;
    printf("\n\n\n");
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
