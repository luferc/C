/*
MATERIA: TALLAER DE ESTRUCTURA DE ARCHIVOS.
MAESTRO: JOYA LOMELI.
NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO.
CODIGO: 304776313
CARRERA: ING. COMPUTACION
PROGRAMA: APUNTADORES TERCERA PARTE.
CARACTERISTICA: APUNTADOR FLOTANTE.(SON MUY PODEROSOS)
FECHA: 28/OCTUBRE/2009 
*/
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    float cal1,cal2,cal3;
    float *apunta;
    
    printf("\n\n\t CALIFICACION --> ");
    scanf("%f",&cal1);
    apunta=&cal1;
    printf("\n\n\t CALIFICACION CAPTURADA --> %f \n",*apunta);
    printf("\n\n\t DIRECCION DE MEMORIA --> %i \n",apunta);// CAMBIAR VARIABLE A ENTERO INT. OJO..!
    
    printf("\n\n\t CALIFICACION --> ");
    scanf("%f",&cal2);
    apunta=&cal2;
    printf("\n\n\t CALIFICACION CAPTURADA --> %f \n",*apunta);
    printf("\n\n\t DIRECCION DE MEMORIA --> %i \n",apunta);// CAMBIAR VARIABLE A ENTERO INT. OJO..!
    
    printf("\n\n\t CALIFICACION --> ");
    scanf("%f",&cal3);
    apunta=&cal3;
    printf("\n\n\t CALIFICACION CAPTURADA --> %f \n",*apunta);
    printf("\n\n\t DIRECCION DE MEMORIA --> %i \n",apunta);// CAMBIAR VARIABLE A ENTERO INT. OJO..!
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
