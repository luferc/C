/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: ESTRUCTURAS CON MENU.                       $
$                                                      $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$          
*/
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    struct constructor
    {
           char nombre[30];
           char sangre[5];
           int tel,edad,op;
           };// TERMINA LA ESTRUCTURA.
           constructor directo;// NOMBRE DE LA ESTRUCTURA Y VARIABLE DE CONTROL O ACCESO.
           while (op!=6)
           {
           printf("\n\n\n");
           printf("\t\t CAPTURA DE DATOS     \n");
           printf("\t\t                      \n");
           printf("\t\t (1)...NOMBRE         \n");
           printf("\t\t (2)...EDAD           \n");
           printf("\t\t (3)...TELEFONO       \n");
           printf("\t\t (4)...CELULAR        \n");
           printf("\t\t (5)...TIPO DE SANGRE \n");
           printf("\t\t (6)...SALIR          \n");
           printf("\n\n\n");
           printf("\t\t SELECCIONE   ");
           scanf("%i",&op);
           system("cls");
           switch (op)
           {
                  case 1://NOMBRE
                  printf("\n\n\t\t NOMBRE:  ");
                  scanf("%s",&directo.nombre);
                  break;
                  case 2://EDAD
                  printf("\n\n\t\t EDAD:  ");
                  scanf("%i",&directo.edad);
                  break;
                  case 3://TELEFONO
                  printf("\n\n\t\t TELEFONO:  ");
                  scanf("%i",&directo.telefono);
                  break;
                  case 4://CELULAR
                  printf("\n\n\t\t NOMBRE  ");
                  scanf("%i",&directo.celular);
                  break;
                  case 5://TIPO SANGRE
                  printf("\n\n\t\t NOMBRE  ");
                  scanf("%s",&directo.sangre);
                  break;
                  case 6://SALIR
                  printf("\n\n\n");
                  printf("\n\t\t CERVANTES FERNANDO....!");
                  break;
                  default:
                  printf("\n\n\n");
                  printf("\n\t\t ����������������������� \n");
                  printf("  \t\t �  X           X      � \n");
                  printf("  \t\t �    X       X        � \n");
                  printf("  \t\t �      X   X          � \n");
                  printf("  \t\t �        X            � \n");
                  printf("  \t\t �      X   X          � \n");
                  printf("  \t\t �     X      X        � \n");
                  printf("  \t\t �   X          X      � \n");
                  printf("  \t\t ����������������������� \n");
                  printf("\n\n\n");
                 }//FIN SWITCH                 
    system("PAUSE");
    system("cls");
}//FIN WHILE.
    return EXIT_SUCCESS;
}
