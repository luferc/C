/*
MATERIA: TALLAER DE ESTRUCTURA DE ARCHIVOS.
MAESTRO: JOYA LOMELI.
NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO.
CODIGO: 304776313
CARRERA: ING. COMPUTACION
PROGRAMA: APUNTADORES PRIMERA PARTE.
CARACTERISTICA: APUNTADOR ENTERO INT.(SON MUY PODEROSOS)
FECHA: 27/OCTUBRE/2009 
*/
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    // DECLARACION VARIABLES
    int *apuntador; //apuntador *.
    int edad1=35;
    int edad2=18;
    int edad3=69;
    
    //uso del apuntador:
    apuntador=&edad1;// ASIGNAR LA PRIMERA VARIABLE "OBLIGATORIO"
    printf("\n\n\t VARIABLE 1 = %i \n",*apuntador);
    printf("\n\n\t DIRECCION MEMORIA --> %i",apuntador);//imprime direccion de mamoria de la variable.
    for(int k=1;k<=5;k++)
    {
    fflush(0);// YA NO ARROJA BASURA.
    apuntador--;
    printf("\n\n\t SIGUIENTE VARIABLE  = %i \n",*apuntador);
    printf("\n\n\t DIRECCION MEMORIA --> %i",apuntador);
    printf("\n\n");
    system("PAUSE");
    }//FIN DEL CICLO FOR
    return EXIT_SUCCESS;
}
