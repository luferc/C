/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: FUNCIONES.                                  $
$          SIMPLE, QUE REGRESEN VALOR Y CON PARAMETROS $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/   
#include <cstdlib>
#include <iostream>

using namespace std;

// FUNCIONES.

char nombre()//........FUNCION SIMPLE.
{
     char nom[30];
     printf("\n\n");
     printf("\n\n\t NOMBRE: ");
     scanf("%s",&nom);
     printf("\n\n\t SU NOMBRE ES --> %s \n\n",nom);
 }
 int validar(int eda)//.FUNCION REGRESA VALOR.
 {
         printf("\n\n\t EDAD: %i",eda);
         return eda;
 }
 
 int dinero(int mo)//....FUNCION CON PARAMETROS.
 {
     printf("\n\n");
     printf("\n\n\t RECIBO --> $%i \n\n",mo);
 }
 int menu()//.......FUNCION SIMPLE.
 {
       //MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   ..............................\n");
    printf("\t   .               MENU         .\n");
    printf("\t   .                            .\n");
    printf("\t   .   (1)--> FUNCION SIMPLE    .\n");
    printf("\t   .   (2)--> FUNCION RETURN    .\n");
    printf("\t   .   (3)--> FUNCION PARAMETRO .\n");
    printf("\t   .   (4)--> SALIR             .\n");
    printf("\t   ..............................\n");
 }
//MAIN:
int main(int argc, char *argv[])
{
    //DECLARACION DE VARIABLES:
    int a,e,d;
    int op=0;
    
    while(op!=4)
    {
    //FUNCION SIMPLE.
    menu();
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op);
    system("cls");
    switch(op)
    {
    case 1://FUNCION SIMPLE.
    //printf("\n\n\t NOMBRE: ");
    nombre();
    system("PAUSE");
    break;
    
    case 2://FUNCION RETURN X. 
    int sal;
    printf("\n\n\t EDAD: ");
    scanf("%i",&e);
    sal = validar(e);
    if(sal>=17)
    {
    printf("\n\n\t MAYOR DE EDAD \n");
    }
    else
    {    
    printf("\n\n\t MENOR DE EDAD \n");
    }
    system("PAUSE");                      
    break;
    
    case 3://FUNCION PARAMETROS.
    printf("\n\n\t TE MANDO --> $ ");
    scanf("%i",&d);
    dinero(d);
    system("PAUSE");                          
    break;
    
    case 4://SALIR.
    printf("\n\n\n");
    printf("\n\t\t**");
    printf("\n\t\t  F");
    printf("\n\t\t   I");
    printf("\n\t\t    N");
    printf("\n\t\t    ***");
    printf("\n\n\n");
    break;
    
    default://ERROR.
          printf("\n");
          printf("\n\t E");
          printf("\n\t  R");
          printf("\n\t   R");
          printf("\n\t    O");
          printf("\n\t     R");
          printf("\n");
          printf("\t\t        ....................  \n");
          printf("\t\t       ..  x        x     ..  \n");                    
          printf("\t\t      . .    x    x      . .  \n");
          printf("\t\t     .  .      x        .  .  \n");
          printf("\t\t    .   .    x   x     .   .  \n");
          printf("\t\t   .    .  x       x  .   x.  \n");
          printf("\t\t   ...................x  x .  \n");
          printf("\t\t   .    . x   x      .  x  .  \n");
          printf("\t\t   .   .    x        . x  x.   \n");
          printf("\t\t   .  .   x    x     . x  .    \n");
          printf("\t\t   . .  x        x   .x  .     \n");
          printf("\t\t   ..                .  .     \n");
          printf("\t\t   .....................       \n");
    
}//FIN DE SWITCH
    system("cls");
}//FIN DE WHILE
    return EXIT_SUCCESS;
}//FIN WHILE.
