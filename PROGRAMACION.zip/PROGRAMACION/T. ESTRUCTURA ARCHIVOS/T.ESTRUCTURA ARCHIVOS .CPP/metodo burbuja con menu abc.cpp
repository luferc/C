/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: ARREGLOS --> METODO BURBUJA.                $
$               CON MENU IMPRIME ABECEDARIO            $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/    
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int temp,datos[5];
    int op,x;
    while (op!=4)
    {
    
          printf("\n\n\n");
          printf("\t\t * CAPTURA DE DATOS  *  \n");
          printf("\t\t                        \n");
          printf("\t\t (1)...CAPTURAR         \n");
          printf("\t\t (2)...MOSTRAR A --> Z  \n");
          printf("\t\t (3)...MOSTRAR Z --> A  \n");
          printf("\t\t (4)...SALIR            \n");
          printf("\n\n\n");
          printf("\t\t SELECCIONE   ");
          scanf("%i",&op);
          system("cls");
          switch (op)
          {
          case 1:// INTRODUCCIR DATOS.
                   printf("\n\n\n");
                   printf("\n\t\t CAPTURAR \n");
                        for(x=0;x<=4;x++)
                           {
                             printf("\n\t\t TECLEA EL DATO  (%i) -->  ",x+1);
                             scanf("%i",&datos[x]);
                           }// FIN FOR.
               break;
          case 2://MOSTRAR ORDENADOS A-Z.
                   printf("\n\n\n");
                   printf("\n\t\t A - - > Z \n");
                        for (int m=1;m<=4;m++)
                           for(x=0;x<=3;x++)
                           {
                             if(datos[x] > datos[x+1])
                                 {
                                    temp=datos[x]; //PASO 1.
                                    datos[x]=datos[x+1]; //PASO 2.
                                    datos[x+1]=temp;// PASO 3.
                                  }
                              }
                            printf("\n\t\t SALIDA --> ORDENADA \n");
                      for(x=0;x<=4;x++)
                       {
                         printf("\n\t\t DATOS CAPTURADOS (%i) --> %i ",x+1,datos[x]);
                       }
                  break;
          case 3://MOSTRAR ORDENADOS Z-A.
                  printf("\n\n\n");
                  printf("\n\t\t Z - - > A \n");
                      for (int m=1;m<=4;m++)
                          for(x=0;x<=3;x++)
                             {
                               if(datos[x] < datos[x+1])
                                {
                                 temp=datos[x]; //PASO 1.
                                 datos[x]=datos[x+1]; //PASO 2.
                                 datos[x+1]=temp;// PASO 3.
                                }
                            }
          printf("\n\t\t SALIDA --> ORDENADA \n");
          for(x=0;x<=4;x++)
          {
          printf("\n\t\t DATOS CAPTURADOS (%i) --> %i ",x+1,datos[x]);
          }
          break;
          case 4://SALIR.
          printf("\n\n\n");
          printf("\n\t\t CERVANTES FERNANDO....!");
          break;
          default:
                  printf("\n\n\n");
                  printf("\n\t\t ����������������������� \n");
                  printf("  \t\t �  X           X      � \n");
                  printf("  \t\t �    X       X        � \n");
                  printf("  \t\t �      X   X          � \n");
                  printf("  \t\t �        X            � \n");
                  printf("  \t\t �      X   X          � \n");
                  printf("  \t\t �     X      X        � \n");
                  printf("  \t\t �   X          X      � \n");
                  printf("  \t\t ����������������������� \n");
                  printf("\n\n\n");
                 }//FIN SWITCH
    system("PAUSE");
    system("cls");
    }// FIN DE WHILE.
    return EXIT_SUCCESS;
}
