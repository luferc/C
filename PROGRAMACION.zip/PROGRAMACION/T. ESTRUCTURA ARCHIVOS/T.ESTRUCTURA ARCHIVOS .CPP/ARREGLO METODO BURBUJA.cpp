#include <cstdlib>
#include <iostream>

using namespace std;

/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: ARREGLOS --> METODO BURBUJA.                $
$               SIMULADOR DEL METODO BURBUJA           $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/    
int main(int argc, char *argv[])
{
    int datos[5];
    int x,y,temp; //(temp=temporal).
    
    printf("\n\t\t METODO BURBUJA \n");
    for(x=0;x<=4;x++)
    {
    printf("\n\t\t TECLEA EL DATO  (%i) -->  ",x+1);
    scanf("%i",&datos[x]);
    }
    for (int m=1;m<=4;m++)// ESTE CICLO FOR ORDENA DE MAYOR  A MENOR.
    for(x=0;x<=4;x++)
    {
    if(datos[x] > datos[x+1])
    {
    temp=datos[x]; //PASO 1.
    datos[x]=datos[x+1]; //PASO 2.
    datos[x+1]=temp;// PASO 3.
    }
    }
    printf("\n\t\t SALIDA --> ORDENADA \n");
    for(x=0;x<=4;x++)
    {
    printf("\n\t\t DATOS CAPTURADOS (%i) --> %i ",x+1,datos[x]);
    }
    printf("\n\n\n");
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
