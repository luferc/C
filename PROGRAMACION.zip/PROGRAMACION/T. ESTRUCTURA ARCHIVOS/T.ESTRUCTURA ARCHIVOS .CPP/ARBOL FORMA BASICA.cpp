#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int arbol [5];
    int cual,k;
    char res;
    printf("\n\t *** ARBOL *** \n");
    // ciclo:
    for(k=0;k<=4;k++)
    {
    printf("\n\t DAME EL DATO [%i]-->  ",k+1);
    scanf("%i",&arbol[k]);
    }
    do
    {
    printf("\n\t SACAR DE DATOS ");
    printf("\n\t CUAL REGISTRO? --> ");
    scanf("%i",&cual);
    
    printf("\n\t DATO PEDIDO --> %i \n",arbol[cual-1]);
    printf("\n\t DESEA SACAR OTRO DATO? -->  ");
    scanf("%s",&res);
    }while(res!='n');
    printf("\n\t FIN \n\n");
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
