/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO:CAPTURA DE CALIFICACIONES CON ARREGLOS.      $
$           HACER UN MEN DE OPCIONES USANDO ARREGLOS.  $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$          
*/
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int cal[5];
    int op,sel,i=0,x=0;
    while (op!=3)
    {
          printf("\n\n\n");
          printf("\t\t CAPTURA DE DATOS \n");
          printf("\t\t                  \n");
          printf("\t\t (1)...CAPTURAR   \n");
          printf("\t\t (2)...CONSULTAR  \n");
          printf("\t\t (3)...SALIR      \n");
          printf("\n\n\n");
          printf("\t\t SELECCIONE   ");
          scanf("%i",&op);
          system("cls");
          switch (op)
          {
                 case 1: // CAPTURAR.
                     printf("\n\n\n\t\t INGRESE LAS CALIFICACIONES \n");
                     for(i=1;i<6;i++)
                     {
                     printf("\n\t\t (%i)...CALIFICACION - ->  ",i);
                     scanf("%i",&x);
                     cal[i]=x;
                     }
                     break;
                 case 2: // CONSULTAR.
                     printf("\n\n\n\t\t CONSULTA DE CALIFICACIONES \n");
                     for(i=1;i<6;i++)
                     printf("\n\t\t (%i)...CALIFICACION = %i ",i,cal[i]);
                     printf("\n\n\n");
                     break;
                 case 3:// SALIR.
                     break;
                     default:
                             printf("\n\n\n\t\t ERROR");
                             }// FIN SWITCH.
                     
                                      
    system("PAUSE");
    system("cls");
}// fin while.
    return EXIT_SUCCESS;
}// FIN MAIN.
