/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: EJEMPLO DE ACCESO DIRECTO (BINARIOS).       $
$   MENU: ALTAS,CONSULTAS,MODIFICAR Y BAJAS.           $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/   

//LIBRERIAS: 
#include <cstdlib>
#include <iostream>
#include <conio.h>
/*
SEEK_SET: revisa de la posicion 0 del bloque hasta el ultimo dato.
SEEK_CUR: revisa las posiciones de 1 en 1 (uno en uno).
SEEK_END: revisa la posicion hasta el final.
*/
using namespace std;

int main(int argc, char *argv[])
{
    struct datos
    {
    //DECLARACION DE ARCHIVOS.
    char nom[20];
    int edad;
   };//fin strut.
   
    //DECLARACION DE ARCHIVOS.
    datos control;
    FILE *archivo;
    FILE *temporal;
    char otro;
    int i=1,bloque=0;
    int op=0,op2=0,rt=0;
    int numreg=0, cual=0;
    //MENU:
    while (op!=5)
    {   
 
          system("cls");
          printf("\n\t\t ** ARCHIVOS BINARIOS (DIRECTOS) ** \n");
          printf("\n\n\n");
          printf("\t\t   �������������������������� \n");
          printf("\t\t   �         MENU           � \n");
          printf("\t\t   �   (1)...ALTAS          � \n");
          printf("\t\t   �   (2)...CONSULTAS      � \n");
          printf("\t\t   �   (3)...MODIFICACIONES � \n");
          printf("\t\t   �   (4)...BAJAS          � \n");
          printf("\t\t   �   (5)...SALIR          � \n");
          printf("\t\t   �������������������������� \n");
          printf("\n\t\t SELECCIONE -->  ");
          scanf("%i",&op);
          system("cls");          
          switch(op)
          {
          case 1:// ALTAS.
          archivo=fopen("datos.bin","wb");
          fseek(archivo,0,SEEK_END); // Ubica el apuntador al final del archivo                    
          bloque=sizeof(datos); //  Determina el tama�o de la estructura
          rt = ftell(archivo) / bloque; // Cuenta los registros almacenados
          //ciclo
          do
          {
          system("cls");
          printf("\n\t\t ** ENTRADA DE DATOS (ALTAS) ** \n");
          printf("\n\t\t DATO --> [%i] \n",i);
          i++;
          printf("\n\t\t (1)...NOMBRE -->  ");
          scanf("%s",&control.nom);// PARA ENTRADA DE DATOS HACIA LA ESTRUCTURA.
          printf("\n\t\t (2)...EDAD   -->  ");
          scanf("%i",&control.edad);// PARA ENTRADA DE DATOS HACIA LA ESTRUCTURA.
          fwrite(&control,sizeof(datos),1,archivo);
          rt = rt + 1;
          fwrite(&control,1,bloque,archivo);
          printf("\n\n");    
          printf("\n\t\t DATO ALMACENADO \n");
          printf("\n\t\t TOTAL DE REGISTROS --> [%i] \n",rt);
          printf("\n\t\t DESEA ALMACENAR OTRO DATO? ( SI <--> NO )\n\t\t ��-->  ");
          otro=getch();
          }
          // CIERRA EL ARCHIVO.
          while (otro!='n');
          fclose(archivo);
          break;
          
          case 2://CONSULTAS.
          archivo = fopen("datos.bin","rb");
          fseek(archivo,0,SEEK_END); // Ubica el apuntador al final del archivo                    
          bloque=sizeof(datos); //  Determina el tama�o de la estructura
          rt = ftell(archivo) / bloque; // Cuenta cuantos registros tiene
          fseek(archivo,0,SEEK_SET); // Ubica el apuntador al inicio del archivo
      	   do
          {
          //SUBMENU.
          system("cls");
          printf("\n\n");
          printf("\n\t\t ** MENU DE CONSULTAS --> (ARCHIVOS DIRECTOS) ** \n");
          printf("\n\n\n");
          printf("\t\t   ������������������������������� \n");
          printf("\t\t   �              MENU           � \n");
          printf("\t\t   �   (1)...DATOS SECUENCIALES  � \n");
          printf("\t\t   �   (2)...DATOS DIRECTOS      � \n");
          printf("\t\t   �   (3)...MENU PRINCIPAL      � \n");
          printf("\t\t   ������������������������������� \n");
          printf("\n\t\t SELECCIONE -->  ");
          scanf("%i",&op2);
          system("cls");          
          // EL SUB-MENU:
          switch(op2)
          {
          case 1: 
          printf("\n\t\t CONSULTAS SECUENCIALES \n\n");
          printf(" NOMBRE \t\t EDAD\n");
          printf("---------------------------------------------\n");
          fseek(archivo,0,SEEK_END);
          fseek(archivo,0,SEEK_SET);
          while (!feof(archivo) )
          {
          fread(&control,1,sizeof(datos),archivo);
          printf(" %s \n",control.nom);
          printf("\t\t\t %i \n",control.edad);
          }
          printf("\n\n LISTO --> OPRIMA [ENTER]");
          getch();
          break;
          
          case 2:
          fseek(archivo,0,SEEK_END);
          rt = ftell(archivo)/sizeof(datos);
          fseek(archivo,0,SEEK_SET);
          printf("\n\n\t CONSULTA DIRECTA");
          printf("\n\n\t EL ARCHIVO TIENE --> [%i] DATOS REGISTRADOS ",rt);
          printf("\n\n\t CUAL REGISTRO DESEA CONSULTAR? -->  ");
          scanf("%i",&numreg);
          if (numreg==0) {fclose(archivo);fclose(temporal);break;}
          if (numreg>rt)
          {
          printf("\n");
          printf("\n\t E");
          printf("\n\t  R");
          printf("\n\t   R");
          printf("\n\t    O");
          printf("\n\t     R");
          printf("\n");
          }
          else
          {
          numreg =  numreg -1;
          numreg = numreg*sizeof(datos);
          fseek(archivo,numreg,0);
          fread(&control,1,sizeof(datos),archivo);
          printf("\n\n");
          printf("\t     ..............................\n");
          printf("\t     .  NOMBRE:--> .    %s         \n",control.nom); 
          printf("\t     ..............................\n");
          printf("\t     .  EDAD:  --> .     %i        \n",control.edad);
          printf("\t     ..............................\n");
          printf("\n\n\n\n");
          system("pause");
          }
          printf("\n\n OPRIMA [ENTER]");
          getch();
          break;
          } // Del switch(op2)
          }//fin do
          while(op2!=3); 
          fclose(archivo);
          break;			 
          
          case 3://MODIFICACIONES.
          archivo = fopen("datos.bin","r+b");
          fseek(archivo,0,SEEK_END); // Ubica el apuntador al final del archivo                    
          rt = ftell(archivo) / sizeof(datos); // Cuenta cuantos registros tiene
          fseek(archivo,0,SEEK_SET); // Ubica el apuntador al inicio del archivo
          do
          {					 
          system("cls");
          printf("\n\n");
          printf("\n\t\t ** MENU DE MODIFICACIONES --> (ARCHIVOS DIRECTOS) ** \n");
          printf("\n\n\n");
          printf("\t\t   ������������������������������� \n");
          printf("\t\t   �              MENU           � \n");
          printf("\t\t   �   (1)...MODIFICAR DATO      � \n");
          printf("\t\t   �   (2)...MENU PRINCIPAL      � \n");
          printf("\t\t   ������������������������������� \n");
          printf("\n\t\t SELECCIONE -->  ");
          scanf("%i",&op2);
          system("cls");          
          // EL SUB-MENU:
          
          switch(op2)
          {
          case 1: 
          printf("\n\t\t CONSULTAS DIRECTAS \n\n");
          printf(" NOMBRE \t\t EDAD\n");
          printf("---------------------------------------------\n"); 
          fseek(archivo,0,SEEK_SET);
          i=1;
          while (!feof(archivo) )
          {
          fread(&control,1,sizeof(datos),archivo);
          printf("%i = %s \t\t\t %i \n",i,control.nom,control.edad);
          i=i+1;
          }
          printf("\n\n\t EL ARCHIVO TIENE --> [%i] REGISTRADOS",rt);
          printf("\n\t CUAL DATO DESEA BORRAR? -->  ");
          scanf("%i",&numreg);
          printf("\n\t (0=SALIR): ");
          if (numreg==0) 
          {
          fclose(archivo);
          break;
          }
          if (numreg>rt)
          printf("\n\n ESCRIBA UN NUM. MENOR");
          else
          {
          printf("\n\n\t NUEVO NOMBRE: ");
          scanf("%s",&control.nom);
	      printf("\n\n\t NUEVA EDAD:  ");
          scanf("%i",&control.edad);
          numreg =  numreg -1;
          numreg = numreg*sizeof(datos);
          fseek(archivo,numreg,0);
          fwrite(&control,1,sizeof(datos),archivo);
          printf("\n\n\t DATO MODIFICADO");
          }
          printf("\n\n OPRIMA [ENTER]");
          getch();
          break;
          } // Del switch(op2)
          }while(op2!=2); 
          fclose(archivo);
          break;
          
          case 4://BAJAS.
          
          break;
          
          case 5://salir.
          printf("\n\n\n");
          printf("\n\t\t**");
          printf("\n\t\t  F");
          printf("\n\t\t   I");
          printf("\n\t\t    N");
          printf("\n\t\t    ***");
          printf("\n\n\n");
          
          break;
          default://error.
          printf("\n");
          printf("\n\t E");
          printf("\n\t  R");
          printf("\n\t   R");
          printf("\n\t    O");
          printf("\n\t     R");
          printf("\n");
          printf("\t\t        ....................  \n");
          printf("\t\t       ..  x        x     ..  \n");                    
          printf("\t\t      . .    x    x      . .  \n");
          printf("\t\t     .  .      x        .  .  \n");
          printf("\t\t    .   .    x   x     .   .  \n");
          printf("\t\t   .    .  x       x  .   x.  \n");
          printf("\t\t   ...................x  x .  \n");
          printf("\t\t   .    . x   x      .  x  .  \n");
          printf("\t\t   .   .    x        . x  x.   \n");
          printf("\t\t   .  .   x    x     . x  .    \n");
          printf("\t\t   . .  x        x   .x  .     \n");
          printf("\t\t   ..                .  .     \n");
          printf("\t\t   .....................       \n");
    
          }//FIN SWITCH.
    system("cls");
}//fin while.
    return EXIT_SUCCESS;
}//fin main.
