/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: EJEMPLO:FUNCIONAMIENTO DE UNA LISTA,COLA,   $
$          PILA Y ARBOL CON MENU.                      $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
*/   

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    //SIMPLES ARREGLOS DECLARADOS:
    int lista[5];
    int cola[5];
    int pila[5];
    int arbol[5];
    char res;
    //DECLARACION DE VARIABLES:
    int op,l,k,cual;
    //DATOS DE ENTRADA
    while(op!=5)
    {
    //MENU
    system("cls");
    printf("\n\n\n");
    printf("\t   ....................................\n");
    printf("\t   .               MENU               .\n");
    printf("\t   .                                  .\n");
    printf("\t   .   (1)--> INGRESAR DATOS EN LISTA .\n");
    printf("\t   .   (2)--> CONSULTAR DATOS EN PILA .\n");
    printf("\t   .   (3)--> CONSULTAR DATOS EN COLA .\n");
    printf("\t   .   (4)--> CONSULTAR DATOS EN ARBOL.\n");
    printf("\t   .   (5)--> SALIR                   .\n");
    printf("\t   ....................................\n");
    printf("\n\n\t SELECCIONE - - > ");
    scanf("%i",&op);
    system("cls");
    switch(op)
    {
    case 1://INGRESAR DATOS A LA LISTA.
    printf("\n\t LISTA \n");
    for(l=0;l<=4;l++)
    {
    printf("\n\t [%i]DATO --> ",l+1);
    scanf("%i",&lista[l]);
    //ASIGNACION
    cola[l]=lista[l];
    pila[l]=lista[l];
    arbol[l]=lista[l];
    }// fin de for.
    printf("\n\n\t LISTO..!\n\n");
    system("PAUSE");
    break;
    
    case 2://CONSULTA DATOS EN PILA.
    
    //PILA: UNA SERIE DE ELEMENTOS O DATOS QUE EL ULTIMO
    //      EN ENTRAR VA SER EL PRIMERO EN SALIR.
    printf("\n\n\t CONSULTA DE DATOS EN LA PILA \n");
    for (l=4;l>=0;l--)
    {
    if (l==4)
    printf("\n\t [%i]EL ULTIMO DATO EN ENTRAR �--> %i \n",l+1,pila[l]);
    else
    printf("\n\t [%i]EL DATO SIGUIENTE --> %i \n",l+1,pila[l]);
    }//fin de for.
    system("PAUSE");
    break;
    
    case 3://CONSULTA DATOS EN COLA.
    printf("\n\n\t CONSULTA DE DATOS EN LA COLA \n");
    for (l=0;l<=4;l++)
    {
    if (l==0)
    printf("\n\t [%i]EL PRIMERO EN ENTAR �--> %i \n",l+1,cola[l]);
    else
    printf("\n\t [%i]EL SIGUIENTE EN ENTRAR �--> %i \n",l+1,cola[l]);
    }
    system("PAUSE");
    break;
    
    case 4://CONSULTA DATOS EN ARBOL.
    printf("\n\t *** ARBOL *** \n");
    // ciclo:
    for(k=0;k<=4;k++)
    {
    printf("\n\t DAME EL DATO [%i]-->  ",k+1);
    scanf("%i",&arbol[k]);
    }
    do
    {
    printf("\n\t SACAR  DATOS ");
    printf("\n\t CUAL REGISTRO? --> ");
    scanf("%i",&cual);
    
    printf("\n\t DATO PEDIDO --> %i \n",arbol[cual-1]);
    printf("\n\t DESEA SACAR OTRO DATO? -->  ");
    scanf("%s",&res);
    }while(res!='n');
    printf("\n\t FIN \n\n");
    

    break;
    
    case 5://SALIR DEL PROGRAMA.
          printf("\n\n\n");
          printf("\n\t\t**");
          printf("\n\t\t  F");
          printf("\n\t\t   I");
          printf("\n\t\t    N");
          printf("\n\t\t    ***");
          printf("\n\n\n");       
    break;
    
    default:
          printf("\n");
          printf("\n\t E");
          printf("\n\t  R");
          printf("\n\t   R");
          printf("\n\t    O");
          printf("\n\t     R");
          printf("\n");
          printf("\t\t        ....................  \n");
          printf("\t\t       ..  x        x     ..  \n");                    
          printf("\t\t      . .    x    x      . .  \n");
          printf("\t\t     .  .      x        .  .  \n");
          printf("\t\t    .   .    x   x     .   .  \n");
          printf("\t\t   .    .  x       x  .   x.  \n");
          printf("\t\t   ...................x  x .  \n");
          printf("\t\t   .    . x   x      .  x  .  \n");
          printf("\t\t   .   .    x        . x  x.   \n");
          printf("\t\t   .  .   x    x     . x  .    \n");
          printf("\t\t   . .  x        x   .x  .     \n");
          printf("\t\t   ..                .  .     \n");
          printf("\t\t   .....................       \n");
    
}//fin de switch.
    system("cls");
    }//fin while.
    return EXIT_SUCCESS;
}
