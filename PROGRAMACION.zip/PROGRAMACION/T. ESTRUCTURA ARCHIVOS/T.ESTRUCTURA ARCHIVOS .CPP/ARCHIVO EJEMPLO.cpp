#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    FILE *archivo;//ARCHIVO.
    char nom[30];
    char dom[50];
    char res;
    int op,edad,tel;
    while(op!=3)
    {
                printf("\n\n\n");
                printf("\n\t\t PROGRAMA QUE SIMULA LA FUNCION DE ARCHIVOS ENTRADA Y SALIDA \n");
                printf("\n\n\n");
                printf("\n\t\t             MENU           \n");
                printf("\n\t\t   (1).....INTRODUCIR DATOS \n");
                printf("\t\t     ( ALTAS --> ENTRADAS )   \n");
                printf("\n\t\t   (2).....CONSULTAR DATOS  \n"); 
                printf("\t\t     (CONSULTA --> SALIDA )   \n");
                printf("\n\t\t   (3).....SALIR            \n"); 
                printf("\n\n\t\t SELECCIONE   ");
                scanf("%i",&op);
                system("cls");
                switch(op)
                {
                case 1://INTRODUCIR DATOS.
                         archivo = fopen("PERSONA.txt","w");
                         do
                         {
                         system("cls");
                         printf("\n\t\t CAPTURA DE DATOS \n");
                         printf("\n\t\t ARCHIVO DE TEXTO \n");
                         printf("\n\t\t NOMBRE -->  ");
                         scanf("%s",&nom);
                         printf("\n\t\t DOMICILIO -->  ");
                         scanf("%s",&dom);
                         printf("\n\t\t EDAD -->  ");
                         scanf("%i",&edad);
                         printf("\n\t\t TELEFONO -->  ");
                         scanf("%i",&tel);
                         
                         fprintf(archivo,"%s\n",nom); // Almacenamiento de datos
                         fprintf(archivo,"%s\n",dom); // de los datos de la variable hacia el archivo
                         fprintf(archivo,"%i\n",edad); // fisico llamdo "PERSONA.txt".
                         fprintf(archivo,"%i\n",tel);
                         
                         printf("\n\t\t DESEA ALMACENAR OTRO DATO (S/N)");
                         scanf("%s",&res);
                         }while(res!='n');
                         fclose(archivo);
                         system("cls");
                break;
                case 2: // CONSULTA DATOS
                        archivo = fopen("PERSONA.txt","r");
                        do
                        {
                        system("cls");
                        if(feof(archivo))
                        printf("\n\t\t ARCHIVO VACIO \n\n");
                        
                        else
                        {
                            
                        fscanf(archivo,"%s\n",&nom);
                        fscanf(archivo,"%s\n",&dom);
                        fscanf(archivo,"%i\n",&edad);
                        fscanf(archivo,"%i\n",&tel);
                        
                        printf("\n\t\t NOMBRE    -->  %s",nom);
                        printf("\n\t\t DOMICILIO -->  %s",dom);
                        printf("\n\t\t EDAD      -->  %i",edad);
                        printf("\n\t\t TELEFONO  -->  %i",tel);
                        }
                        printf("\n\t\t DESE HACER OTRA CONSULTA (S/N)");
                        scanf("%s",&res);
                        }while (res!='n');                        
                        fclose(archivo);
                        system("cls");
                break;
                case 3:// SALIR.
                       printf("\n\t\t FIN \n\n\n");
                break;
                default:
                       printf("\n\t\t NUMERO INCORRECTO \n\n");
               }
               }//FIN WHILE
    return EXIT_SUCCESS;
}
