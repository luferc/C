///////////////////////////////////////////////////////////////////////////
// ARCHIVOS BINARIOS - DIRECTOS                                         //
// Autor: Lic. Javier Joya Lomeli                                      //
// Fecha Elaboracion: 05/nov/2008                                     //
///////////////////////////////////////////////////////////////////////
// CENTRO UNIVERSITARIO DE LA COSTA                                 //
//             (CUC)                                               //
////////////////////////////////////////////////////////////////////
//        Funcionando al 100%                                    //
//  1.- Altas (Entrada de datos)                                //
//  2.- Consultas (Secuencial y Directos                       //                              //
///////////////////////////////////////////////////////////////
//    Pendientes las rutinas de:                             //
//   3.- Modificaciones (Cambios)                           //
//  4.- Bajas (Eliminar datos)                             //
////////////////////////////////////////////////////////////

#include <cstdlib>
#include <iostream>
#include <conio.h>

using namespace std;

int main(int argc, char *argv[])
{

     struct datos
	 {
		 char nombre [15];
		 int edad;
	 };

     datos control;
    
	FILE *arch;
	FILE *temp;
     int op,op2,totalreg=0;
	int bloque,numreg=0, cual=0;
	char otro;

	do
	{
		system("cls"); // Puede usar clrscr();
		printf("MENU DE OPCIONES - ARCHIVOS DIRECTOS ");
		printf("\n\n 1.- Capturar datos - entrada");
		printf("\n 2.- Consultas (Secuenciales o directas)");
		printf("\n 0.- Salir de este programa");
		printf("\n\n Teclee un numero (1,2,0):");
		scanf("%i",&op);
          switch(op)
		  {
		  case 1:
                    arch = fopen("datos.bin","wb"); // Si no existe lo crea, si existe se abre para anexar
	                 fseek(arch,0,SEEK_END); // Ubica el apuntador al final del archivo                    
	                 bloque=sizeof(datos); //  Determina el tama�o de la estructura
	                 totalreg = ftell(arch) / bloque; // Cuenta los registros almacenados
                  	do
			          {
				           system("cls");
                           printf("- ARCH. DE ACCESO DIRECTO -- ALTAS --\n\n");
	                       printf("\n Total de reg. almacenados = %i",totalreg);
	                       printf("\n\nNombre :");scanf("%s",&control.nombre);
	                       printf("\nEdad   :");scanf("%i",&control.edad);
	                           totalreg = totalreg + 1;
				                 // Almacenamiento de datos              
                               fwrite(&control,1,bloque,arch);    
                               printf("\n Un dato almacenado, desea almacenar otro (s/n):");
		                       otro=getch();
						}while (otro!='n');
                          fclose(arch);
				 break;
		  case 2:  arch = fopen("datos.bin","rb");
		            fseek(arch,0,SEEK_END); // Ubica el apuntador al final del archivo                    
	                 bloque=sizeof(datos); //  Determina el tama�o de la estructura
	                 totalreg = ftell(arch) / bloque; // Cuenta cuantos registros tiene
                      fseek(arch,0,SEEK_SET); // Ubica el apuntador al inicio del archivo
					   do
					   {					 
					     system("cls");
						 printf("\n\n MENU DE CONSULTAS - ARCH. DIRECTOS");
						 printf("\n\n 1.- Consultar todos los datos (secuenciales)");
						 printf("\n 2.- Consultar solo un dato (directo)");
                         printf("\n 3.- Regresar al menu principal");
						 printf("\n\n Elija un numero (1,2,3):");
						 scanf("%i",&op2);

							 switch(op2)
								{
								case 1: printf("\n\n CONSULTAS SECUENCIALES \n\n");
								         printf(" NOMBRE \t\t EDAD\n");
								         printf("---------------------------------------------\n");
										 fseek(arch,0,SEEK_SET);
									     while (!feof(arch) )
										 {
											 fread(&control,1,sizeof(datos),arch);
											 printf("%s \t\t\t %i \n",control.nombre,control.edad);
										 }
										 printf("\n\n ARCHIVO VACIO, OPRIMA [ENTER]");getch();
									    break;
								case 2: fseek(arch,0,SEEK_END);
									    totalreg = ftell(arch)/sizeof(datos);
										fseek(arch,0,SEEK_SET);
									        printf("\n\n CONSULTAS DIRECTAS");
										printf("\n\n El archivo tiene [%i] registros",totalreg);
										printf("\n Cual reg. desea consultar (0=Salir):");
										scanf("%i",&numreg);
										if (numreg==0) {fclose(arch);fclose(temp);break;}
                                           if (numreg>totalreg) printf("\n\n ESCRIBA UN NUM. MENOR");
										      else
										        {
											     numreg =  numreg -1;
											     numreg = numreg*sizeof(datos);
										         fseek(arch,numreg,0);
										         fread(&control,1,sizeof(datos),arch);
									             printf("\n\n NOMBRE:%s",control.nombre); 
										         printf("\nEDAD :%i",control.edad);
										        }
										 printf("\n\n OPRIMA [ENTER]");getch();
									    break;
							 } // Del switch(op2)
					   }while(op2!=3); 
					   fclose(arch);
			  		  break;			   
		  } // Del switch(op)	
	}while(op!=0); // Del menu principal
	    system("PAUSE");
    return EXIT_SUCCESS;
} // Del programa principal

