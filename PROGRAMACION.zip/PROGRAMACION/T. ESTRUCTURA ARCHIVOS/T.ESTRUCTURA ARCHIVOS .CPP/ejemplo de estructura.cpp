/* 
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
$ AUTOR:  CERVANTES MARTINEZ LUIS FERNANDO.            $
$ CODIGO: 304776313                                    $
$ CARRERA: INGENERIA COMPUTACION.                      $
$ MATERIA: ESTRUCTURA DE ARCHIVOS.                     $
$ TRABAJO: EJEMPLO DE ESTRUCTURAS                      $
$           FUNCION DE UNA ESTRUCTURA.                 $
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$          
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    struct estructura
    {
           int codigo;
           int edad;
           };//TERMINA LA ESTRUCTURA.
           estructura acceso;// NOMBRE DE LA ESTRUCTURA Y VARIABLE DE CONTROL O ACCESO.
           printf("\n\n\n\t\t   * EJEMPLO DE ESTRUCTURA * \n");
           printf("\n\t\t INGRESE DATOS \n");
           printf("\n\t\t   CODIGO: ");
           scanf("%i",&acceso.codigo);//LLAMA LA ESTRUCTURA.
           printf("\n\t\t   EDAD: ");
           scanf("%i",&acceso.edad);
           printf("\n\n\n");
           //SALIDA
           printf("\n\t\t DATOS ADQUIRIDOS \n");
           printf("\n\t\t CODIGO --> %i \n",acceso.codigo);
           printf("\n\t\t EDAD   --> %i \n",acceso.edad);
           
           
    system("PAUSE");
    return EXIT_SUCCESS;
}
