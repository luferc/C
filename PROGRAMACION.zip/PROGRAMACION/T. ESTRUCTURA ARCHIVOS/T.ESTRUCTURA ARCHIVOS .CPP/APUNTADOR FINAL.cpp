/*
MATERIA: TALLAER DE ESTRUCTURA DE ARCHIVOS.
MAESTRO: JOYA LOMELI.
NOMBRE: CERVANTES MARTINEZ LUIS FERNANDO.
CODIGO: 304776313
CARRERA: ING. COMPUTACION
PROGRAMA: APUNTADORES CUARTA PARTE.
CARACTERISTICA: APUNTADOR FINAL.(SON MUY PODEROSOS)
FECHA: 29/OCTUBRE/2009 
*/
#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int *z;//APUNTADOR INT.
    float *y;//APUNTADOR FLOAT.
    char *x;//APUNTADOR CHAR.
    int a=17;
    float b=99.9;
    char c[20];
    
    //ENTERO
    z=&a;//asignar valor al apuntador.
    printf("\n\n\t BATERIA [1] --> %i VECES CARGADA \n",*z);
    printf("\n\n\t DIRECCION MEMORIA --> %i ",z);
    printf("\n\n");
    
    //FLOTANTE
    y=&b;//asignar valor al apuntador.
    printf("\n\n\t TIENE --> %f CARGA ",*y);
    printf("\n\n\t DIRECCION MEMORIA --> %i ",y);
    printf("\n\n");
    
    /*//CARACTER
    x=&c[0];//asignar valor al apuntador.
    printf("\n\n\t MARCA --> %s ",&c);
    printf("\n\n\t DIRECCION MEMORIA --> %i ",x);
    printf("\n\n");*/
    
    //ciclo:
            
    printf("\n\n\t MARCA -->  ");
    scanf("%s",&c);
    int t;
    t=strlen(c);
    for(int k=0;k<=t;k++)
    {
    x=&c[k];fflush(0);
    printf("\n\n\t LA MARCA [%i]--> %s",k,x);
    printf("\n\n\t DIRECCION MEMORIA --> %i",x);//imprime direccion de mamoria de la variable.
    printf("\n\n");
    system("PAUSE");
    }//fin for
    
    system("PAUSE");
    return EXIT_SUCCESS;
}//fin main
