/*
 * Tarjeta.java
 *
 * Created on 28 de mayo de 2009, 02:02 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package biblio;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class Tarjeta {
    
    /** Creates a new instance of Tarjeta */
    public Tarjeta() {
    }
    
}
