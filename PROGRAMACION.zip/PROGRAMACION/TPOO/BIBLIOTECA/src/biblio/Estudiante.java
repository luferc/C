/*
 * Estudiante.java
 *
 * Created on 28 de mayo de 2009, 02:01 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package biblio;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class Estudiante {
    //  MIEMBROS DE DATOS.
    private String nombre;
    private String correoE;
    /** Creates a new instance  of Estudiante */
    //CONSTRUCTOR.
    public Estudiante() {
        nombre = "Desconocido";
        correoE = "Desconocido";
    } 
    // DEVUELVE EL CORREO ELECTRONICO DE ESTE ESTUDIANTE.
    public String obtenCorreoE(){
        return correoE;
    }
    // DEVUELVE EL NOMBRE DE ESTE ESTUDIANTE.
    public String obtenNombre(){
        return nombre;
    }
    // ASIGNA EL CORREO ELECTRONICO DE ESTE ESTUDIANTE. 
    public void estableceCorreoE(String correo){
        correoE = correo;
    }
    //ASIGNA EL DE ESTE ESTUDIANTE.
    public void estableceNombre(String nomEstudiante){
        nombre = nomEstudiante;
    }
    //NUMERO DE LIBROS QUE SACAN.
    public void registraSalida(int numDeLibros){
        cuentaLibPres = cuentaLibpres + numDeLibros;
    }
    //DEVUELVE EL NUMERO DE LIBROS PRESTADOS.
    public int obtenNumLibros(){
        return cuentaLibPres;
    }
    //DEVUELVE EL NOMBRE DEL PROPIETARIO DE ESTA TARJETA.
    public String obtenNumLibros(){
    return propietario.obtenNombre();
    }
    //ASIGNA COMO PROPIETARIO DE ESTA TARJETA AL ESTUDIANTE
    public void establecePropietario(Estudiante estudiante){
        propietario = estudiante;
    }
    //DEVUELVE LA REPRESENTACION DE ESTA TARJETA.
    public String aString(){
        return "Nombre del Propietario:" + propietario.obtenNombre() + "\n" +
                "Correo electrinico:   " + propietario.obtenCorreoE()+ "\n" +
                "Libros prestados:     " +cuentaLibPres;
    }
}
