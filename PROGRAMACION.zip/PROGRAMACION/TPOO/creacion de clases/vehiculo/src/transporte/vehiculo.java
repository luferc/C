/*
 * vehiculo.java
 *
 * Created on May 21, 2009, 1:47 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package transporte;

/**
 *
 * @author 206619789
 */
public class vehiculo {
    //mienbro de datos
    private String nomPropietario;
    private String numPlacas;
    private String numSerie;
    
    /** Creates a new instance of vehiculo */
    public vehiculo() {
        //constructor.Inicia miembro de datos
        nomPropietario="desconocido";
        numPlacas="desconocido";
        numSerie="desconocido";
       }
    
    public String ObtenNomPropietario(){
     return nomPropietario;
     }
    public String ObtenNumPlacas(){
         return numPlacas;
    }
    public String ObtenNumSerie(){
         return numSerie;
    }
    
   
     public void establceNumPlacas(String Placas){
   numPlacas=Placas;    
    }
      public void establceNumSerie(String serie){
   numSerie=serie;    
    }

    public void estableceNomPropietario(String nombre) {
    nomPropietario=nombre; ;
    }

    
}
