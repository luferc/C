/*
 * Main.java
 *
 * Created on May 19, 2009, 2:18 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package creaciondeclases;
class vehiculo{
    private String nomPropietario;
    private String numPlacas;
    private String numSerie;
    public vehiculo (){
        nomPropietario= "Desconocido";
        numPlacas= "Desconocido";
        numSerie= "desconocido";
    }
    public String obtenNombrePropietario(){
        return nomPropietario;
    }
        public String obtenNumPlacas(){
            return numPlacas;
        }
        public String obtenNumSerie(){
            return numSerie;
    }
        public void estableceNomPropietario(String nombre){
            nomPropietario=nombre;
        }
        public void estableceNumSerie(String serie){
            numSerie=serie;
        }
        public void estableceNumPlacas(String placas){
            numPlacas=placas;
}
/**
 **
 * @author 206619789
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {}
        // TODO code application logic here
}     
    }
