/*
 * Ejercicio29.java
 *
 * Created on 24 de marzo de 2009, 02:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package ejercicio29;
import java.util.*;
/**
 *
 * @author FERNANDO CERVANTES
 */
public class Ejercicio29 {
    
    /** Creates a new instance of Ejercicio29 */
    public Ejercicio29() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre1,nombre2,primerApellido,segundoApellido;
        Scanner escaner = new Scanner(System.in);
        
        /* Datos de Entrada */
        System.out.println("\n\t INGRESE SU NOMBRE COMPLETO:");
        nombre1 = escaner.next();
        nombre2 = escaner.next();
        System.out.println("\n\t INGRESE SU PRIMER APELLIDO:");
        primerApellido = escaner.next();
        System.out.println("\n\t INGRESE SU SEGUNDO APELLIDO:");
        segundoApellido = escaner.next();
        System.out.println("\n\t "+segundoApellido.toUpperCase()+","+nombre1.toUpperCase()+" "+nombre2.toUpperCase()+" "+primerApellido.substring(0,1).toUpperCase()+".");
        
    }
    
}
