/*
 * tortuga.java
 *
 * Created on 7 de abril de 2009, 12:40 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package tortuga;
import galapagos.*;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class tortuga {
    
    /** Creates a new instance of tortuga */
    public tortuga() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Turtle tortuga;
        tortuga = new Turtle();
        tortuga.move(50); //se mueve 50 pixeles.
        tortuga.turn(90);//gira 90 grados en elsentido del reloj.
        tortuga.move(50); //se mueve 50 pixeles.
        tortuga.turn(90);//gira 90 grados en elsentido del reloj.
        tortuga.move(50); //se mueve 50 pixeles.
        tortuga.turn(90);//gira 90 grados en elsentido del reloj.
        tortuga.move(50); //se mueve 50 pixeles.
    }
    
}
