/*
 * estudiante.java
 *
 * Created on May 28, 2009, 1:19 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package biblio;

/**
 *
 * @author 206619789
 */
public class estudiante {
    private String nombre;
    private String correoE;
   
    /** Creates a new instance of estudiante */
    public estudiante() {
      nombre="Desconocido";
        correoE="Desconocido";  
    }
    public String obtenCorreoE(){
        return correoE;
    }
    public String obtenNombre(){
        return nombre;
    } 
    public void estableceCorreoE(String direccion){
        correoE= direccion;
    }
    public void estableceNombre(String nomEstudiante){
        nombre= nomEstudiante;
    }
}
