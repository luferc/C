/*
 * Tarjetadebiblioteca.java
 *
 * Created on May 28, 2009, 1:58 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package biblio;

/**
 *
 * @author 206619789
 */
public class Tarjetadebiblioteca {
     //estudiante propietario de esta tarjeta
    
    private estudiante propietario;
    // numero de libros prestados
    private int cuentaLibPres;
    // constructor
    
    /** Creates a new instance of Tarjetadebiblioteca */
    public Tarjetadebiblioteca() {
         propietario=null;
        cuentaLibPres=0;
    }
    //numero de libros q se sacan
    
    public void registraSalida (int numDeLibros){
    cuentaLibPres = cuentaLibPres + numDeLibros;
   }
    // devuelve el numero de libros prestados
   public int obtenNumLibros ( ){
   return cuentaLibPres;
}
   //devuelve el nombre del propietario de esta tarjeta 
   public String obtenNomPropietario (){
    return propietario.obtenNombre( );
   }
   // Asigna como propietario de esta tarjeta al estudiante
   public void establecePropietario(estudiante estudiante){
       propietario=estudiante;
   }
   // Devuelve la referencia de esta tarjeta
   public String aString( ){
       return "nombre del propietario: " +" " + propietario.obtenNombre( ) + "\n" + "Correo Electronico:  " +" " + propietario.obtenCorreoE( ) + "\n" + "Libros Prestados: " + " " + cuentaLibPres;  
   }
   }