/*
 * apli.java
 *
 * Created on 28 de mayo de 2009, 02:15 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package bibloapli;

import paquete1.TargetaDeBibloteca;
import paquete1.estudiante;

/**
 *
 * @author adrian
 */
public class apli {
    
    /** Creates a new instance of apli */
    public apli() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        estudiante estudiante1; 
        TargetaDeBibloteca tarjeta1,tarjeta2;
        int total,pres1,pres2; 
        
        estudiante1 = new estudiante( );
        estudiante1.estableceNombre("juan java");
        estudiante1.estableceCorreoE("jj@javauni.edu");
        
        tarjeta1=new TargetaDeBibloteca( );
        tarjeta1.establecePropietario(estudiante1);
        tarjeta1.registraSalida(3);
        
        tarjeta2 = new TargetaDeBibloteca( );
        tarjeta2.establecePropietario(estudiante1);
        tarjeta2.registraSalida(4);
        
        total=tarjeta1.obtenNumLibros()+tarjeta2.obtenNumLibros();
      
        
        
        
        
        System.out.println("informacion de la tarjeta1: ");
        System.out.println(tarjeta1.aString()+"\n");
        
        System.out.println(tarjeta2.aString()+"\n");
        System.out.println("el total es "+total);
        
        
        
        
        
        
    }
    
}
