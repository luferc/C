/*
 * CalculadorDePrestamo.java
 *
 * Created on 23 de abril de 2009, 01:28 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package calculadordeprestamo;
import java.util.*;
import java.text.*;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class CalculadorDePrestamo {
    
    /** Creates a new instance of CalculadorDePrestamo */
    public CalculadorDePrestamo() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        final int MESES_EN_EL_A�O = 12;
        double montoPrestamo,tasaInteresAnual;
        double pagoMensual,pagoTotal;
        double tasaInteresMensual;
        int periodoPrestamo;
        int numDePagos;
        
        Scanner escaner = new Scanner(System.in);
        escaner.useDelimiter(System.getProperty("line.separator"));
        
        DecimalFormat df = new DecimalFormat("0.00");
        // DEscribe el Programa.
        System.out.prinln("Este programa calcula los pagos mensuales");
        
        
    }
    
}
