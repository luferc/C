/*
 * vehiculo.java
 *
 * Created on 21 de mayo de 2009, 01:52 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package transporte;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class vehiculo {
    /* Miembros de Datos */
    private string nomPropietario;
    private string numPlacas;
    private int numSerie;
     /** Creates a new instance of vehiculo */
    /* Constructor */
    public vehiculo() {
        nomPropietario = "NO REGISTRADO"
        numPlacas      = "NO REGISTRADO"
        numSerie       = "NO REGISTRADO"
    }
    public string obtenNomPropietario(){
        return nomPropietario;
    }
    public void estableceNomPropietario(){
        nomPropietario = nombre;
    }
  public string obtenNumPlacas(){
      return numPlacas;
  }
  public void estableceNumPlacas(string numero){
      numPlacas = numero;
  }
  public string obtenNumSerie(){
      return numSerie;
  }
  public void estableceNumSerie(string numero){
      numSerie = numero;
  }
}
