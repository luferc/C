/*
 * registravehiculo.java
 *
 * Created on May 21, 2009, 2:40 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package registravehiculo;

import transporte.vehiculo;

/**
 *
 * @author 206619789
 */
public class registravehiculo {
    
    /** Creates a new instance of registravehiculo */
    public registravehiculo() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // TODO code application logic here
        vehiculo auto1, auto2;
        String propietario1, propietario2;
        auto1=new vehiculo();
        auto1.estableceNomPropietario("Fernando Cervantes");
        auto1.establceNumPlacas("JDK-3423");
        auto1.establceNumSerie("RT23007");
        auto2=new vehiculo();
        auto2.estableceNomPropietario("Alexis Martinez");
        auto2.establceNumPlacas("JDK-5080");
        auto2.establceNumSerie("LTRT27679");
        //salida de informacion
        propietario1=auto1.ObtenNomPropietario();
        propietario1=auto1.ObtenNumPlacas();
        propietario1=auto1.ObtenNumSerie();
        propietario2=auto2.ObtenNomPropietario();
        propietario2=auto2.ObtenNumPlacas();
        propietario2=auto2.ObtenNumSerie();
        
        System.out.println(auto1.ObtenNomPropietario( ) + "  " + auto1.ObtenNumPlacas()+ " " + auto1.ObtenNumSerie( )) ;
        
        System.out.println(auto2.ObtenNomPropietario( ) +" " + auto2.ObtenNumPlacas()+ " " + auto2.ObtenNumSerie());
       
        
        
        
        
    }
    
}
