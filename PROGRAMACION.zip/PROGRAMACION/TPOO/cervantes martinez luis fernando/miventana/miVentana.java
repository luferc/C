/*
 * miVentana.java
 *
 * Created on 10 de marzo de 2009, 02:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package miventana;
import javax.swing.*;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class miVentana {
    
    /** Creates a new instance of miVentana */
    public miVentana() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        JFrame miVentana;
        miVentana = new JFrame();
        miVentana.setSize(300,200);
        miVentana.setTitle("MI PRIMER PROGRAMA JAVA");
        miVentana.setVisible(true);
        try{Thread.sleep(500);}catch(Exception e){};
        miVentana.setVisible(false);
        try{Thread.sleep(500);}catch(Exception e){};
        miVentana.setVisible(true);
        // TODO code application logic here
    }
    
}
