/*
 * pizarra.java
 *
 * Created on 17 de febrero de 2009, 02:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package pizarra;
import javabook2.SketchPad;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class pizarra {
    
    /** Creates a new instance of pizarra */
    public pizarra() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SketchPad   pizarra;
pizarra=new SketchPad ();
pizarra.setVisible(true);
    }
    
}
