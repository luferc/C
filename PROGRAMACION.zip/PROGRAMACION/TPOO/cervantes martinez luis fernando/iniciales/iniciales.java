/*
 * iniciales.java
 *
 * Created on 17 de marzo de 2009, 11:46 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package iniciales;
import java.util.*;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class iniciales {
    
    /** Creates a new instance of iniciales */
    public iniciales() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre1,nombre2,apellidoPat,apellidoMat;
        Scanner escaner = new Scanner(System.in);
       
        
        /* Datos de Salida */
        System.out.println("\n\t INGRESE SU NOMBRE COMPLETO Y APELLIDOS:");
        nombre1 = escaner.next();
        nombre2 = escaner.next();
        apellidoPat = escaner.next();
        apellidoMat = escaner.next();
        
        System.out.println("\n\t Nombre:"+nombre1+" "+nombre2);
        System.out.println("\n\t APELLIDOS:"+apellidoPat+" "+apellidoMat);
        
        
        System.out.println("\n\t LAS INICIALES DE SU NOMBRE COMPLETO Y APELLIDOS SON:");
        System.out.println(nombre1.substring(0,1)+nombre2.substring(0,1)+apellidoPat.substring(0,1)+apellidoMat.substring(0,1));
        System.out.println(nombre1.substring(0,1).toUpperCase()+nombre2.substring(0,1).toUpperCase()+apellidoPat.substring(0,1).toUpperCase()+apellidoMat.substring(0,1).toUpperCase());
        escaner.useDelimiter(System.getProperty("line.separator"));
        
        
    }
    
}
