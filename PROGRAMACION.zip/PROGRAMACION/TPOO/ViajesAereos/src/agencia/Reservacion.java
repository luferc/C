/*
 * Reservacion.java
 *
 * Created on 9 de junio de 2009, 02:27 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package agencia;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class Reservacion {
    
    // MIEMBRO DE DATOS:
    private Vuelo vuelo;
    private String idReserva;
    private String cliente;
    private String asientos;
    
    /** Creates a new instance of Reservacion */
    
    //CONSTRUCTOR:
    public Reservacion() {
        vuelo = null;
        idReserva = null;
        cliente = null;
        asientos = null;
    }
    
}
