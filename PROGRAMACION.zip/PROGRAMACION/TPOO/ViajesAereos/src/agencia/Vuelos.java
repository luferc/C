/*
 * Vuelos.java
 *
 * Created on 9 de junio de 2009, 02:26 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package agencia;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class Vuelos {
    
    // MIEMBRO DE DATOS:
    private String idVuelo;
    private String destino;
    private String horaSalida;
    private String cupoDisponible;
    
    /** Creates a new instance of Vuelos */
    
    // CONSTRUCTOR:
    public Vuelos() { 
        idVuelo        = "no asignado";
        destino        = "no asignado";
        horaSalida     = "no asignado";
        cupoDisponible = "no asignado";
    }// FIN CONSTRUCTOR.
    public String obtenIdVuelo(){
        return idVuelo;
    }
    public String obtenDestino(){
    return destino;
    }
    public String obtenCupoDisponible(){
        return cupoDisponible;
    }
    public void estableceIdVuelo(String alaska-van-77){
        idVuelo = alaska-van-77;
    }
    public void estableceDestino(String vancuber){
        destino = vancuber;
    }
    public void estableceHoraSalida(String 06:35 am){
        horaSalida = 06:35 am;
    }
    public void estableceCupodisponible(String 200 pasajeros){
        cupoDisponible = 200 pasajeros;
    }
}
