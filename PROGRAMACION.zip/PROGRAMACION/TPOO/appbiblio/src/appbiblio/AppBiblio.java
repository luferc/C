/*
 * AppBiblio.java
 *
 * Created on 28 de mayo de 2009, 02:03 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package appbiblio;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class AppBiblio {
    
    /** Creates a new instance of AppBiblio */
    public AppBiblio() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
