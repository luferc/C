/*
 * registroAuto.java
 *
 * Created on 21 de mayo de 2009, 02:38 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package registroauto;

/**
 *
 * @author FERNANDO CERVANTES
 */
public class registroAuto {
    
    /** Creates a new instance of registroAuto */
    public registroAuto() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Automovil auto1;
        String propietario1;
        auto1 = new Automovil();  // CREA Y ASIGNA VALORES A AUTO1.
        auto1.estableceNomPropietario ("Fernando Cervantes");
        auto1.estableceNumPlacas("JDK34-38");
        auto1.estableceNumSerie("23177FG5588");
        // Salida de la informacion.
        propietario1 = auto1.obtenNomPropietario();
        propietario1 = auto1.obtenNumPlacas();
        propietario1 = auto1.obtenNmSerie();
        //system.out.prinln(propietario1 + "TIENE UN AUTO DEPORTIVO";
        
    }
    
}
