#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int a,b;
    float area,perimetro;
    
    printf( "introduzca las variables de entrada\n" );
    printf( "ancho\n" );
    scanf( "%d",&a );
    printf( "altura\n" );
    scanf( "%d",&b );
    area = (a*b);
    perimetro = 2*(a+b);
    printf( "area es :%f\n""el perimetro es :%f\n",area,perimetro );
  
  system("PAUSE");	
  return 0;
}
