#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int l, ti, pa;
  double pm, r, n;
  
  //entradita//
  printf( "buenas tardes! n\n" );
  printf( "introducir la cantidad prestada n\n" );
  scanf( "%f", &l);
  
  printf( "cantidad permitida n\n" );
  
  printf( "introduzca la taza de interes n\n" );
  scanf( "%f", &l);
  
  printf( "ahora ponga el tipo de periodo deseado n\n" );
  scanf( "%f", &l);
  
  
  
  system("PAUSE");	
  return 0;
}
