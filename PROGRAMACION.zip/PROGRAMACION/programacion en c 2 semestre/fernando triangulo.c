#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
    int a,b,area;
    float suma,h,per;
    
    printf( "dame los valores de el lado 1 y 2\n" );
    printf( "lado1\n" );
    scanf( "%d",&a );
    printf( "lado2\n" );
    scanf( "%d",&a );
    area = ( a*b )/2;
    suma = ( a*b ) + ( b*b );
    h = sqrt ( suma );
    per = a+b+h;
    printf( "area es :d\n""el perimetro es :%f\n""hipotenusa es :%f\n",area,per,h);
    
  
  system("PAUSE");	
  return 0;
}
