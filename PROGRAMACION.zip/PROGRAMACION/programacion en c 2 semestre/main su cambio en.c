
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  //  "cambio en: $"  //
  double tp, pr,dll,g,o,u;
  int DL, Q, D, N, P;
  
  
  //  ENTRADA  //
  printf( "******************************************************************************** \n ******************************   CAMBIO EN :  ******************************** \n ******************************************************************************" );
  
  printf( "\n\n  SU COMPRA ES DE:  \n\n" );
  
  printf( "\n\n  TOTAL:   \n\n $" );
  scanf( "%Lf", &tp );  /* total a pagar */ 
  
  printf( "\n\n  RECIBO EFECTIVO DE:  \n\n $" );
  scanf( "%Lf", &pr );  /* pago realizado */
  
  //  formula #1  //
  
  dll = pr - tp;  /* resta del pago realizado menos el total a pagar */
  
  //  SALIDA  //
  
  printf( "\n\n  su cambio es de:  \n\n $%Lf\n",dll ); /*  cambio $ */
  
  dll = (int) pr - tp;
  
  printf( "\n\n  cambio en dollars:  \n\n" );
dll=((pr-tp)-DL)*100;
printf( "\n  DOLLARS: %d \n", DL );

  
  printf( "\n\n  cambio en quarters:  \n\n" );
Q=(int)DL/25;
g=dll-(Q*25);
printf( "\n  QUARTERS:  %d \n", Q );



  printf( "\n\n  cambio en dimes:  \n\n" );
D=(int)g/10;
  printf( "\n\n  DIMES: %d \n\n", D );


  
  printf( "\n\n  cambio en nickel:  \n\n" );
  N=(int)u/5;
  u=o-(N*5);
  printf("\n\n  NICKELS: %d \n\n",N );



  printf( "\n\n  cambio en pennies:  \n\n" );
  P=(int)u;
  printf( "\n\n  PENNIES %d  \n\n", P );


  printf( "\n\n\n                      GRACIAS POR SU VISITA!                       \n\n\n" );  
  
  
  
    system("PAUSE");	
  return 0;
}

