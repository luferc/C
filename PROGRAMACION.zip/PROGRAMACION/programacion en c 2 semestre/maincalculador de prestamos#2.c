
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float l,tia,tim,pm,pt;
  int p,n;
  int cantidad1,cantidad2;
  
  //entradita//
  
   printf( "****************************CALCULADOR DE PRESTAMOS*****************************" );
   
   printf( "\n\n\n                                 BIENVENIDO                                      \n\n\n" );
  
  printf( "\n\n  su credito disponible es de:  \n\n $" );
  scanf( "%d", &cantidad1 );  /* lectura de la cantidad disponible */
  printf( "\n\n  su credito autorizado es de:  \n\n $" );
  scanf( "%d", &cantidad2 );
 if ( cantidad1 >= cantidad2 ) {
       printf( "\n $%d es mayor o igual que $%d \n", cantidad1, cantidad2 );
       } /* fin de if */ 
  
  printf( "\n\n  INTRODUZCA LA CANTIDAD A PRESTAR PARA SU CLIENTE EN: \n\n $" );
  scanf( "%f", &l);
  
  printf( "\n\n  CREDITO PERMITIDO \n\n" );
  
  printf( "\n\n  LA TASA DE INTERES ANUAL EN PORCIENTO, ES DEL:  \n\n " );
  scanf( "%f", &tia);
  tim=(tia/12)/100;
  
  printf( "\n\n  LA TASA DE INTERES MENSUAL SERA DE:  \n\n $" );
  printf( "%f",tim );
  
  printf( "\n\n SU CREDITO ANUAL A PAGAR, SERA A UN TIEMPO DE:   \n\n" );
  scanf( "%d",&p );
  n=p*12;
  
  printf( "\n\n  MESES A PAGAR  \n\n" );
  printf( "%d",n );
  
  pm=(1*tim)/(1-pow(1/(1+tim), n));
  pt=pm*n;
  
  
  
  //salidita//
  
  printf(  "\n\n  SU PAGO MENSUAL SERIA DE:$ %g \n\n",pm  );
  printf(  "\n\n  SU PAGO TOTAL ES DE $: %g \n\n",pt  );
  printf(  "\n\n\n       GRACIAS       \n\n\n"  );
  
  
  
  system("PAUSE");	
  return 0;
}
