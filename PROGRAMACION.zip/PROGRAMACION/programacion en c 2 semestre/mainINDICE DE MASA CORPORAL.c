#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    //  INDICE DE MASA CORPORAL  //
    float imc, w,h;
    
    
    //  entrda  //
    printf(  "introduzca su peso en kg:" );
    scanf( "%f", &w );
    
    printf( "introduzca su altura" );
    scanf( "%f", &h );
    
    // formula  //
    imc=w/pow (h,2);
    
    
    //  salida  //
    printf( "tu masa corporal es de: %f\n",imc );    /* resultado de su peso y su altura */
    
    
  
  system("PAUSE");	
  return 0;
}
