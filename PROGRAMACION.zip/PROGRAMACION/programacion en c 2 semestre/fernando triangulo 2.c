#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
  int a,b,area;
  float suma,h,peri;
  
  printf( "introduzca las variables de entrada para sacar el area perimetro y hipotenusa de un triangulo\n" );
  printf( "base a\n" );
  scanf( "%d",&a );
  printf( "lado b\n" );
  scanf( "%d",&b );
  area = (a*b) /2;
  suma = (a*a)+(b*b);
  h = sqrt (suma);
  peri = a+b+h;
  printf( "area es :%d\n""el perimetro es :%f\n""hipotenusa es :%f\n",area,peri,h );
  system("PAUSE");	
  return 0;
}
