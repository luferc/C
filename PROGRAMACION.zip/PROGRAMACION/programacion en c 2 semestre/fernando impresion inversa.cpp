#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int a,b,c,d;
    printf("introduzca las variables de entrada\n");
    scanf("%d%d%d%d",&b,&c,&a,&d);
    scanf("impresion invertida\n");
    printf("%d %d %d %d",d,a,c,b);
    return 0;
    system("PAUSE");
    return EXIT_SUCCESS;
}
