#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main(int argc, char *argv[])
{
    double p1,p2,p3;
    long fn,n;
    
    printf( "introduzca el numero de periodos n\n" );
    scanf( "%f",&n );
    
    p1 = 1/ sqrt (5);
    p2 = pow ((1+sqrt(5))/2,n);
    p3 = (int) ((p1*p2)-p3);
    
    printf( "los resultados de los periodos son %fn\n");
  
  system("PAUSE");	
  return 0;
}
